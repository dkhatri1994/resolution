package com.rcf.ebr.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.annotation.Resource;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import com.rcf.ebr.bean.EmployeeDetails;
import com.rcf.ebr.bean.ReceiptBookAndCourierDetails;
import com.rcf.ebr.bean.ReceiptBookDetails;
import com.rcf.ebr.db.DatabaseManager;

public class ReceiptBookingUtilities {
	private Connection con = null;
	private PreparedStatement psmt = null;
	private ResultSet rs = null;
	private CallableStatement csmt = null;
	
	@Resource(name="jdbc/MyUatDB")
	private DataSource dataSource;
	
	
	private static ReceiptBookingUtilities receiptBookingUtilities = null;
	
	public static synchronized ReceiptBookingUtilities getInstance(){
		if(receiptBookingUtilities==null)
			receiptBookingUtilities = new ReceiptBookingUtilities();
		
		return receiptBookingUtilities;
	}
	/**
	 * @author Narayan
	 * @param receiptQuantity
	 * @param requestLetter
	 * @param requestedBy
	 * @param requestName
	 * @param requestTime
	 * @param workStep
	 * @param nextWorkStep
	 * @return insert receipt quantity related details
	 */
	public int requestReceiptBooks(String receiptQuantity, String requestLetter, String requestedBy,String requestName,
			String requestTime, String workStep, String nextWorkStep, String location)throws SQLException{
		int updateStatus=0;
		String query = "insert into EBR_RECEIPT_BOOK_REQUESTS(TXID,RECEIPT_QUANTITY,REQUESTED_BY,REQUESTED_TIME,"+
					   " REQUEST_LETTER,WORKSTEP,NEXT_WORKSTEP,REQUEST_NAME,LOCATION) values('EBR-'||EBR_TXID_SEQ.nextval,?,?,?,?,?,?,?,?)";
		try{
			con = DatabaseManager.getConnection();
			psmt = con.prepareStatement(query);
			psmt.setInt(1, Integer.parseInt(receiptQuantity.trim()));
			psmt.setString(2, requestedBy.trim());
			psmt.setString(3, requestTime.trim());
			psmt.setString(4, requestLetter.trim());
			psmt.setString(5, workStep.trim());
			psmt.setString(6, nextWorkStep.trim());
			psmt.setString(7, requestName.trim());
			psmt.setString(8, location.trim());
			updateStatus = psmt.executeUpdate();
		}
		catch(SQLException s){
			s.printStackTrace();
			System.out.println("exception in requestReceiptBooks method :> "+s.getMessage());
		}
		finally{
			DatabaseManager.closeAllConnection(con, psmt, rs);
		}
		return updateStatus;
	}
	
	/**
	 * @author Narayan
	 * @return All requests for receipt booked
	 * @throws ParseException 
	 */
	@SuppressWarnings("unchecked")
	public JSONArray getReceiptBookRequests(String workstep, String type, String loggedInUser)throws SQLException, ParseException{
		JSONArray jsonArray = new JSONArray();
		JSONObject jsonObject = null;
		String query = null;
		if(workstep.trim().equals("CM") && type.trim().equals("processedRequests")){
			query = "select t1.* from EBR_RECEIPT_BOOK_REQUESTS t1, EBR_RECEIPT_N_COURIER_DETAILS t2 where t1.TXID=t2.TXID"+
					" and upper(t1.REQUESTED_BY)=upper('"+loggedInUser.trim()+"') and t1.REQUEST_STATUS like '%Processed%' "+
					" and t2.IS_CONFIRMED is null order by REQUESTED_TIME";
		}
		else if(workstep.trim().equals("CM") && type.trim().equals("confirmedRequests")){
			query = "select t1.* from EBR_RECEIPT_BOOK_REQUESTS t1, EBR_RECEIPT_N_COURIER_DETAILS t2 where t1.TXID=t2.TXID"+
					" and upper(t1.REQUESTED_BY)=upper('"+loggedInUser.trim()+"') and t1.REQUEST_STATUS like '%Processed%'"+
					" and t2.IS_CONFIRMED like '%YES%' order by REQUESTED_TIME";
		}
		else if(workstep.trim().equals("HO") && type.trim().equals("cmConfirmedRequests")){
			query = "select t1.* from EBR_RECEIPT_BOOK_REQUESTS t1, EBR_RECEIPT_N_COURIER_DETAILS t2 where t1.TXID=t2.TXID"+
					" and upper(t2.RECEIPT_BOOK_ISSUED_BY)=upper('"+loggedInUser.trim()+"') and t1.REQUEST_STATUS like '%Processed%'"+
					" and t2.IS_CONFIRMED like '%YES%' order by REQUESTED_TIME";
		}
		else if(workstep.trim().equals("CM") && type.trim().equals("myRaisedRequests")){
			query = "SELECT * FROM EBR_RECEIPT_BOOK_REQUESTS WHERE upper(REQUESTED_BY)=upper('"+loggedInUser.trim()+"')";
		}
		else{
			query = "select * from EBR_RECEIPT_BOOK_REQUESTS where REQUEST_STATUS is null order by REQUESTED_TIME";
		}
		
		try{
			con = DatabaseManager.getConnection();
			psmt = con.prepareStatement(query);
			rs = psmt.executeQuery();
			while(rs.next()){
				String requestDate = rs.getString("REQUESTED_TIME");
//				System.out.println("requestDate : "+requestDate);
				Date reqDate = new SimpleDateFormat("MMMM dd, yyyy h:mm a").parse(requestDate);
				Date todaydate = new Date();
				long difference =  (todaydate.getTime()-reqDate.getTime())/86400000;
				jsonObject = new JSONObject();
				jsonObject.put("TxID", rs.getString("TXID"));
				jsonObject.put("ReceiptQuantity", rs.getString("RECEIPT_QUANTITY"));
				jsonObject.put("RequestedBy", rs.getString("REQUESTED_BY"));
				jsonObject.put("RequestTime", rs.getString("REQUESTED_TIME"));
				jsonObject.put("RequestLetter", rs.getString("REQUEST_LETTER"));
				jsonObject.put("WorkStep", rs.getString("WORKSTEP"));
				jsonObject.put("NextWorkStep", rs.getString("NEXT_WORKSTEP"));
				jsonObject.put("RequestName", rs.getString("REQUEST_NAME"));
				jsonObject.put("RequestStatus", rs.getString("REQUEST_STATUS")!=null?rs.getString("REQUEST_STATUS"):"Not Processed !");
				jsonObject.put("pendingDays", difference);
				jsonArray.add(jsonObject);
			}		
		}
		catch(SQLException s1){
			s1.printStackTrace();
			System.out.println("Exception in getReceiptBookRequests method :>> "+s1.getMessage());
		}	
		finally{
			DatabaseManager.closeAllConnection(con, psmt, rs);
		}
		return jsonArray;
	}
	/**
	 * @author Narayan
	 * @param txId
	 * @return Receipt book requester details including required receipt booking details
	 * @throws SQLException
	 */
	@SuppressWarnings("unchecked")
	public JSONArray getRequesterDetails(String txId)throws SQLException{
		JSONArray jsonArray = new JSONArray();
		JSONObject jsonObject = null;
		String requesterFirstName=null,requesterLastName=null,requesterNameWithSapid = null,requesterLocation=null;
		String query = "select * from EBR_RECEIPT_BOOK_REQUESTS where TXID='"+txId.trim()+"'";
		try{
			con = DatabaseManager.getConnection();
			psmt = con.prepareStatement(query);
			rs = psmt.executeQuery();
			while(rs.next()){
				jsonObject = new JSONObject();
				jsonObject.put("ReceiptQuantity", rs.getString("RECEIPT_QUANTITY"));
				requesterFirstName = AppMasterInfo.getInstance().getEmployeeInfo(rs.getString("REQUESTED_BY")).getFirstName();
				requesterLastName = AppMasterInfo.getInstance().getEmployeeInfo(rs.getString("REQUESTED_BY")).getLastName();
				requesterLocation = AppMasterInfo.getInstance().getEmployeeInfo(rs.getString("REQUESTED_BY")).getLocation();
				requesterNameWithSapid = requesterFirstName+" "+requesterLastName+" - "+rs.getString("REQUESTED_BY");
				jsonObject.put("RequesterNameWithSapid", requesterNameWithSapid);
				jsonObject.put("RequestTime", rs.getString("REQUESTED_TIME"));
				jsonObject.put("RequestLocation", requesterLocation);
				jsonObject.put("RequestLetter", rs.getString("REQUEST_LETTER"));
				jsonArray.add(jsonObject);
			}
		}
		catch(SQLException s2){
			s2.printStackTrace();
			System.out.println("Exception in getRequesterDetails method :>> "+s2.getMessage());
		}
		finally{
			DatabaseManager.closeAllConnection(con, psmt, rs);
		}
		return jsonArray;
	}
	
	/**
	 * @author Narayan
	 * @param availableReceipts
	 * @param courierAgencyName
	 * @param courierContactNumber
	 * @param courierDispatchDate
	 * @param expectedDeliveryDate
	 * @param courierAddress
	 * @param receiptsForAdjustment
	 * @param receiptBookData
	 * @param txId
	 * @return Save receipts and courier details
	 * @throws SQLException
	 */
	public String saveReceiptAndCourierDetails(String availableReceipts, String courierAgencyName, String courierContactNumber,
			String courierDispatchDate, String expectedDeliveryDate, String courierAddress, String receiptsForAdjustment, 
			String receiptBookData, String txId,String loggedInUser, String receiptBookIssueTime)throws SQLException{
		System.out.println("loggedInUser : "+loggedInUser);
		String courierDetailsSaveStatus = "";
		String saveStatus = "";
		String query ="{call EBR_SAVE_COURIER_DETAILS(?,?,?,?,?,?,?,?,?,?,?)}";
		try{
			con = DatabaseManager.getConnection();
			saveReceiptDetails(con,receiptBookData,txId);
			csmt = con.prepareCall(query);
			csmt.setString(1, txId.trim());
			csmt.setInt(2, Integer.parseInt(availableReceipts.trim()));
			csmt.setInt(3, Integer.parseInt(receiptsForAdjustment.trim()));
			csmt.setString(4, courierAgencyName.trim());
			csmt.setString(5, courierContactNumber.trim());
			csmt.setString(6, courierDispatchDate.trim());
			csmt.setString(7, expectedDeliveryDate.trim());
			csmt.setString(8, courierAddress.trim());
			csmt.setString(9, loggedInUser.trim());
			csmt.setString(10, receiptBookIssueTime.trim());
			csmt.registerOutParameter(11, java.sql.Types.VARCHAR);
			csmt.executeUpdate();
			courierDetailsSaveStatus = csmt.getString(11);
			System.out.println("courierDetailsSaveStatus > "+courierDetailsSaveStatus);
			if(courierDetailsSaveStatus.equals("saved"))
				saveStatus = "saved";
			else
				saveStatus = "notSaved";
		}
		catch(SQLException s3){
			s3.printStackTrace();
			System.out.println("Exception in saveReceiptAndCourierDetails :> "+s3.getMessage());
		}
		finally{
			DatabaseManager.close(con, psmt);
		}
		return saveStatus;
	}
	
	/**
	 * @author Narayan
	 * @param con
	 * @param receiptBookData
	 * @param txId
	 * @throws SQLException
	 * @description save receipt details
	 */
	public void saveReceiptDetails(Connection con, String receiptBookData,String txId)throws SQLException{
		String query = "insert into EBR_RECEIPT_BOOK_DETAILS(TXID,RECEIPT_BOOK_NUMBER,SEQUENCE_START_NUMBER,SEQUENCE_END_NUMBER)"+
					   " values(?,?,?,?)";
		try{
			con.setAutoCommit(false);
			psmt = con.prepareStatement(query);
			String receiptBookRows[] = receiptBookData.trim().split("<END>");
			for(int i=0;i<receiptBookRows.length;i++){
				String []receiptData = receiptBookRows[i].split("##");
				psmt.setString(1, txId.trim());
				psmt.setString(2, receiptData[0]);
				psmt.setString(3, receiptData[1]);
				psmt.setString(4, receiptData[2]);
				psmt.addBatch();
			}
			psmt.executeBatch();
			con.commit();
			con.setAutoCommit(true);
		}
		catch(SQLException s4){
			s4.printStackTrace();
			System.out.println("Exception in saveReceiptDetails method :> "+s4.getMessage());
			con.rollback();
		}
	}
	
	/**
	 * @author Narayan
	 * @param txId
	 * @return Receipt and courier details
	 * @throws SQLException
	 */
	@SuppressWarnings(value = "unchecked")
	public String getReceiptBookAndCourierDetails(String txId)throws SQLException{
		JSONArray jsonArray = new JSONArray();
		JSONObject jsonObject = null;
		JSONObject receiptAndCourierData = null;
		String query = "select * from EBR_RECEIPT_N_COURIER_DETAILS where TXID='"+txId.trim()+"'";
		try{
//			con = dataSource.getConnection();
			con = DatabaseManager.getConnection();
			psmt = con.prepareStatement(query);
			rs = psmt.executeQuery();
			while(rs.next()){
				jsonObject = new JSONObject();
				jsonObject.put("AVAILABLE_RECEIPT_QUANTITY", rs.getInt("AVAILABLE_RECEIPT_QUANTITY"));
				jsonObject.put("RECEIPTS_FOR_ADJUSTMENT", rs.getInt("RECEIPTS_FOR_ADJUSTMENT"));
				jsonObject.put("COURIER_AGENCY", rs.getString("COURIER_AGENCY"));
				jsonObject.put("COURIER_CONTACT_NUMBER", rs.getString("COURIER_CONTACT_NUMBER"));
				jsonObject.put("COURIER_SENDING_DATE", rs.getString("COURIER_SENDING_DATE"));
				jsonObject.put("COURIER_EXP_DELIVERY_DATE", rs.getString("COURIER_EXP_DELIVERY_DATE"));
				jsonObject.put("ADDRESS", rs.getString("ADDRESS"));
				jsonObject.put("RECEIPT_BOOK_ISSUED_BY", rs.getString("RECEIPT_BOOK_ISSUED_BY"));
				jsonObject.put("RECEIPT_BOOK_ISSUE_TIME", rs.getString("RECEIPT_BOOK_ISSUE_TIME"));
				jsonObject.put("REC_COURIER_AGENCY", rs.getString("REC_COURIER_AGENCY"));
				jsonObject.put("REC_COURIER_DATE", rs.getString("REC_COURIER_DATE"));
				jsonObject.put("REC_COURIER_CONTACT", rs.getString("REC_COURIER_CONTACT"));
				jsonArray.add(jsonObject);
			}
			
			receiptAndCourierData = new JSONObject();
			receiptAndCourierData.put("receiptData", getReceiptBookDetails(con,txId));
			receiptAndCourierData.put("courierData", jsonArray);
		}
		catch(Exception s5){
			s5.printStackTrace();
			System.out.println("Exception in getReceiptBookAndCourierDetails : "+s5.getMessage());
		}
		finally{
			DatabaseManager.closeAllConnection(con, psmt, rs);
		}
		return receiptAndCourierData.toString();
	}
	
	/**
	 * @author Narayan
	 * @param con
	 * @param txId
	 * @return receipt details
	 */
	@SuppressWarnings(value="unchecked")
	public JSONArray getReceiptBookDetails(Connection con, String txId){
		JSONArray jsonArray = new JSONArray();
		JSONObject jsonObjectForReceiptDetails = null;
		String query = "select * from EBR_RECEIPT_BOOK_DETAILS where TXID='"+txId.trim()+"'";
		try{
			psmt = con.prepareStatement(query);
			rs = psmt.executeQuery();
			while(rs.next()){
				jsonObjectForReceiptDetails = new JSONObject();
				jsonObjectForReceiptDetails.put("RECEIPT_BOOK_NUMBER", rs.getString("RECEIPT_BOOK_NUMBER"));
				jsonObjectForReceiptDetails.put("SEQUENCE_START_NUMBER", rs.getString("SEQUENCE_START_NUMBER"));
				jsonObjectForReceiptDetails.put("SEQUENCE_END_NUMBER", rs.getString("SEQUENCE_END_NUMBER"));
				jsonArray.add(jsonObjectForReceiptDetails);
			}
		}
		catch(Exception e){
			e.printStackTrace();
			System.out.println("Exception in getReceiptBookDetails : "+e.getMessage());
		}
		return jsonArray;
	}
	
	/**
	 * @author Narayan
	 * @param txId
	 * @return a status of confirmation of courier and receipt details 
	 * @throws SQLException
	 */
	public int confirmReceiptAndCourierDetails(ReceiptBookAndCourierDetails courierDetails)throws SQLException{
		int status = 0;
		String query = "update EBR_RECEIPT_N_COURIER_DETAILS set IS_CONFIRMED='YES',REC_COURIER_AGENCY=?,REC_COURIER_DATE=?,"
				+ "REC_COURIER_CONTACT=? where TXID='"+courierDetails.getTxId().trim()+"'";
		try{
			con = DatabaseManager.getConnection();
			psmt = con.prepareStatement(query);
			psmt.setString(1, courierDetails.getRecCourierAgencyName().trim());
			psmt.setString(2, courierDetails.getRecCourierReceiveDate().trim());
			psmt.setString(3, courierDetails.getRecCourierContactNumber().trim());
			status = psmt.executeUpdate();
		}
		catch(SQLException s6){
			s6.printStackTrace();
			System.out.println("Exception in confirmReceiptAndCourierDetails method : "+s6.getMessage());
		}
		finally{
			DatabaseManager.close(con, psmt);
		}
		return status;
	}
	
	
	public int getCountsForDashboard(String workstep, String type,String loggedInUser)throws SQLException{
		int count = 0;
		String query = null;
		if(workstep.trim().equals("CM") && type.trim().equals("processedRequestsCount")){
			query = "SELECT count(1) FROM EBR_RECEIPT_BOOK_REQUESTS  WHERE upper(REQUESTED_BY)=upper('"+loggedInUser.trim()+"') and "+
					" REQUEST_STATUS LIKE '%Processed%'";
		}
		else if(workstep.trim().equals("CM") && type.trim().equals("confirmedRequestCount")){
			query = "SELECT count(1) FROM EBR_RECEIPT_BOOK_REQUESTS t1, EBR_RECEIPT_N_COURIER_DETAILS t2 WHERE t1.TXID=t2.TXID"+
					" AND t1.REQUEST_STATUS LIKE '%Processed%' AND t2.IS_CONFIRMED LIKE '%YES%' ORDER BY REQUESTED_TIME";
		}
		else if(workstep.trim().equals("CM") && type.trim().equals("myRaisedRequestCount")){
			query = "SELECT count(1) FROM EBR_RECEIPT_BOOK_REQUESTS WHERE upper(REQUESTED_BY)=upper('"+loggedInUser.trim()+"')";
		}
		else if(workstep.trim().equals("CM") && type.trim().equals("receiptsSentToHO")){
			query = "SELECT count(1) FROM EBR_RECEIPT_BOOK_REQUESTS t1, EBR_RECEIPT_BOOK_DETAILS t2"+
					" WHERE t1.TXID=t2.TXID and upper(t1.REQUESTED_BY)=upper('"+loggedInUser.trim()+"') and t2.IS_SENT_TO_HO is not null";
		}
		else if(workstep.trim().equals("CM") && type.trim().equals("totalRequestedReceiptsCount")){
			query = "SELECT sum(t1.RECEIPT_QUANTITY) FROM EBR_RECEIPT_BOOK_REQUESTS t1, EBR_RECEIPT_N_COURIER_DETAILS t2"+
					" WHERE t1.TXID=t2.TXID and upper(t1.REQUESTED_BY)=upper('"+loggedInUser.trim()+"')";
		}
		else if(workstep.trim().equals("CM") && type.trim().equals("processedReceiptsCount")){
			query = "SELECT sum(t2.AVAILABLE_RECEIPT_QUANTITY) FROM EBR_RECEIPT_BOOK_REQUESTS t1, EBR_RECEIPT_N_COURIER_DETAILS t2"+
					" WHERE t1.TXID=t2.TXID and upper(t1.REQUESTED_BY)=upper('"+loggedInUser.trim()+"')";
		}
		else if(workstep.trim().equals("CM") && type.trim().equals("pendingReceiptRequestCount")){
			query = "SELECT sum(t1.RECEIPT_QUANTITY)-sum(t2.AVAILABLE_RECEIPT_QUANTITY) FROM EBR_RECEIPT_BOOK_REQUESTS t1, EBR_RECEIPT_N_COURIER_DETAILS t2"+
					" WHERE t1.TXID=t2.TXID and upper(t1.REQUESTED_BY)=upper('"+loggedInUser.trim()+"')";
		}
		try{
			con = DatabaseManager.getConnection();
			psmt = con.prepareStatement(query);
			rs = psmt.executeQuery();
			if(rs.next())
				count = rs.getInt(1);
			
//			System.out.println("counts : "+count);
		}
		catch(SQLException s7){
			s7.printStackTrace();
			System.out.println("Exception in getCountsForDashboard method : "+s7.getMessage());
		}
		finally{
			DatabaseManager.closeAllConnection(con, psmt, rs);
		}
		return count;
	}
	
	
	@SuppressWarnings("unchecked")
	public JSONArray getAllRequestsWithFilters(String fromDate, String toDate, String location)throws SQLException, ParseException{
//		System.out.println(fromDate.isEmpty()+" : "+toDate.trim()+" : "+location);
		JSONArray jsonArray = new JSONArray();
		JSONObject jsonObject = null;
		String query = "SELECT * FROM EBR_RECEIPT_BOOK_REQUESTS where 1=1";
		if(location!=null && !location.trim().equals("Select")){
			query += " and upper(LOCATION)=upper('"+location.trim()+"')";
		}
		if(fromDate.isEmpty() && !toDate.isEmpty())
			query += " and to_char(to_date(REQUESTED_TIME,'Month DD, YYYY HH:MI AM'))=to_date('"+toDate.trim()+"','DD-MM-YYYY')";
		if(!fromDate.isEmpty() && toDate.isEmpty())
			query += " and to_char(to_date(REQUESTED_TIME,'Month DD, YYYY HH:MI AM'))=to_date('"+fromDate.trim()+"','DD-MM-YYYY')";
		if(!fromDate.isEmpty() && !toDate.isEmpty()){
			query += " and to_char(to_date(REQUESTED_TIME,'Month DD, YYYY HH:MI AM')) between to_date('"+fromDate.trim()+"','DD-MM-YYYY')"+
					" and to_date('"+toDate.trim()+"','DD-MM-YYYY')";
		}
		System.out.println("query : "+query);
		try{
			con = DatabaseManager.getConnection();
			psmt = con.prepareStatement(query);
			rs = psmt.executeQuery();
			while(rs.next()){
				String requestDate = rs.getString("REQUESTED_TIME");
//				System.out.println("requestDate : "+requestDate);
				Date reqDate = new SimpleDateFormat("MMMM dd, yyyy h:mm a").parse(requestDate);
				Date todaydate = new Date();
				long difference =  (todaydate.getTime()-reqDate.getTime())/86400000;
				
//				System.out.println("requestDate dt : "+Math.abs(difference));
				
				jsonObject = new JSONObject();
				jsonObject.put("TxID", rs.getString("TXID"));
				jsonObject.put("ReceiptQuantity", rs.getString("RECEIPT_QUANTITY"));
				jsonObject.put("RequestedBy", rs.getString("REQUESTED_BY"));
				jsonObject.put("RequestTime", rs.getString("REQUESTED_TIME"));
				jsonObject.put("RequestLetter", rs.getString("REQUEST_LETTER"));
				jsonObject.put("WorkStep", rs.getString("WORKSTEP"));
				jsonObject.put("NextWorkStep", rs.getString("NEXT_WORKSTEP"));
				jsonObject.put("RequestName", rs.getString("REQUEST_NAME"));
				jsonObject.put("RequestStatus", rs.getString("REQUEST_STATUS")!=null?rs.getString("REQUEST_STATUS"):"Not Processed !");
				jsonObject.put("PendingDays", difference);
				jsonArray.add(jsonObject);
			}		
		}
		catch(SQLException s8){
			s8.printStackTrace();
			System.out.println("Exception in getReceiptBookRequests method :>> "+s8.getMessage());
		}	
		finally{
			DatabaseManager.closeAllConnection(con, psmt, rs);
		}
		return jsonArray;
	}
	
	@SuppressWarnings("unchecked")
	public JSONArray getAllReceiptBooks(String loggedInUser, String workStep)throws SQLException{
		JSONArray jsonArray = new JSONArray();
		JSONObject jsonObject = null;
		String query = null;
		if(workStep.trim().equals("CM")){
			query = "select t1.* from EBR_RECEIPT_BOOK_DETAILS t1,EBR_RECEIPT_BOOK_REQUESTS t2, "+
					" EBR_RECEIPT_N_COURIER_DETAILS t3 where t1.TXID=t2.TXID and t2.TXID=t3.TXID"+
					" and t1.TXID=t3.TXID and t3.IS_CONFIRMED is not null and t1.IS_SENT_TO_HO is null"+
					" and upper(t2.REQUESTED_BY)=upper('"+loggedInUser.trim()+"')";
		}
		else{
			query = "select t1.* from EBR_RECEIPT_BOOK_DETAILS t1,EBR_RECEIPT_BOOK_REQUESTS t2, "+
					" EBR_RECEIPT_N_COURIER_DETAILS t3 where t1.TXID=t2.TXID and t2.TXID=t3.TXID "+
					" and t1.TXID=t3.TXID and t3.IS_CONFIRMED is not null and t1.IS_SENT_TO_HO is not null";
		}
		
		
		try{
			con = DatabaseManager.getConnection();
			psmt = con.prepareStatement(query);
			rs = psmt.executeQuery();
			while(rs.next()){
				jsonObject = new JSONObject();
				jsonObject.put("TXID", rs.getString("TXID"));
				jsonObject.put("RECEIPT_BOOK_NUMBER", rs.getString("RECEIPT_BOOK_NUMBER"));
				jsonObject.put("SEQUENCE_START_NUMBER", rs.getString("SEQUENCE_START_NUMBER"));
				jsonObject.put("SEQUENCE_END_NUMBER", rs.getString("SEQUENCE_END_NUMBER"));
				jsonArray.add(jsonObject);
			}
		}
		catch(SQLException s9){
			s9.printStackTrace();
			System.out.println("Exception in getAllReceiptBooks method : "+s9.getMessage());
		}
		finally{
			DatabaseManager.closeAllConnection(con, psmt, rs);
		}
		return jsonArray;
	}
	
	public void saveLeafData(String receiptBookNumber, String leafData)throws SQLException{
		String query = "insert into EBR_LEAF_DETAILS(RECEIPT_BOOK_NUMBER,SLIP_NUMBER,LAN,CUSTOMER_NAME,PAYMENT_MODE,AMOUNT,STATUS) "+
					   " values(?,?,?,?,?,?,?)";
		try{
			con = DatabaseManager.getConnection();
			con.setAutoCommit(false);
			psmt = con.prepareStatement(query);
			String leafDataRows[] = leafData.trim().split("<END>");
			for(int i=0;i<leafDataRows.length;i++){
				String leafDataArr[] = leafDataRows[i].split("##");
				psmt.setString(1, receiptBookNumber.trim());
				psmt.setString(2, leafDataArr[0]);
				psmt.setString(3, leafDataArr[1]);
				psmt.setString(4, leafDataArr[2]);
				psmt.setString(5, leafDataArr[3]);
				psmt.setString(6, leafDataArr[4]);
				psmt.setString(7, leafDataArr[5]);
				psmt.addBatch();
			}
			psmt.executeBatch();
			con.commit();
			con.setAutoCommit(true);
		}
		catch(SQLException s10){
			s10.printStackTrace();
			System.out.println("Exception in saveLeafData method : "+s10.getMessage());
			con.rollback();
		}
		finally{
			DatabaseManager.close(con, psmt);
		}
	}
	
	public String validationCounts(String workStep, String queryType, String searchParam)throws SQLException{
		String status = null;
		String query = null;
		if(workStep.equals("CM") && queryType.equals("isLeafDetailsAvailable")){
			query = "select * from EBR_LEAF_DETAILS where RECEIPT_BOOK_NUMBER='"+searchParam.trim()+"'";
		}
		try{
			con = DatabaseManager.getConnection();
			psmt = con.prepareStatement(query);
			rs = psmt.executeQuery();
			if(rs.next()){
				status = "true";
			}
			else
				status = "false";
//			System.out.println("st : "+status);
		}
		catch(SQLException s11){
			s11.printStackTrace();
			System.out.println("Exception in validationCounts method : "+s11.getMessage());
		}
		finally{
			DatabaseManager.closeAllConnection(con, psmt, rs);
		}
		return status;
	}
	
	public void sentReceiptBooksToHO(String selectedReceiptBooks, String courierDetails)throws SQLException{
		String query = "UPDATE EBR_RECEIPT_BOOK_DETAILS set IS_SENT_TO_HO='YES',"+
					   " COURIER_AGENCY_NAME=?,CONTACT_NUMBER=?,SENDING_DATE=?,"+
					   " EXP_DELIVERY_DATE=?,ADDRESS=? where RECEIPT_BOOK_NUMBER=?";
		try{
			con = DatabaseManager.getConnection();
			con.setAutoCommit(false);
			psmt = con.prepareStatement(query);
			String courierDetail[] = courierDetails.trim().split(",");
			String receiptBooks[] = selectedReceiptBooks.trim().split(",");
			for(int i=0;i<receiptBooks.length;i++){
				psmt.setString(1, courierDetail[0]);
				psmt.setString(2, courierDetail[1]);
				psmt.setString(3, courierDetail[2]);
				psmt.setString(4, courierDetail[3]);
				psmt.setString(5, courierDetail[4]);
				psmt.setString(6, receiptBooks[i]);
				psmt.addBatch();
			}
			psmt.executeBatch();
			con.commit();
			con.setAutoCommit(true);
		}
		catch(SQLException s12){
			s12.printStackTrace();
			System.out.println("Exception in sentReceiptBooksToHO method : "+s12.getMessage());
			con.rollback();
		}
		finally {
			DatabaseManager.close(con, psmt);
		}
	}
	
	public int addNewReceiptBook(ReceiptBookDetails receiptBookDetails)throws SQLException{
		int status = 0;
		if(this.checkReceiptBookDuplicacy(receiptBookDetails)==null){
			String query = "INSERT INTO EBR_RECEIPT_BOOK_MASTER(ID,RECEIPT_BOOK_NUMBER,START_SEQUENCE_NUMBER,END_SEQUENCE_NUMBER)"+
					   " VALUES((select nvl(max(ID),0)+1 from EBR_RECEIPT_BOOK_MASTER),?,?,?)";
			try{
				con = DatabaseManager.getConnection();
				psmt = con.prepareStatement(query);
				psmt.setInt(1, Integer.parseInt(receiptBookDetails.getReceiptBookNumber()));
				psmt.setInt(2, Integer.parseInt(receiptBookDetails.getReceiptBookStartSequenceNumber()));
				psmt.setInt(3, Integer.parseInt(receiptBookDetails.getReceiptBookEndSequenceNumber()));
				status = psmt.executeUpdate();
			}
			catch(SQLException s13){
				s13.printStackTrace();
				System.out.println("Exception in addNewReceiptBook method : "+s13.getMessage());
			}
			finally{
				DatabaseManager.close(con, psmt);
			}
		}
		else
			status = 2;
		
		return status;
	}
	public String checkReceiptBookDuplicacy(ReceiptBookDetails receiptBookDetails){
		String status = null;
//		String queryForReceiptBook = "select * from EBR_RECEIPT_BOOK_MASTER where RECEIPT_BOOK_NUMBER="+receiptBookDetails.getReceiptBookNumber().trim();
		String query = "{call EBR_CHECK_RB_DUPLICACY(?,?,?,?,?,?)}";
		try{
			con = DatabaseManager.getConnection();
			csmt = con.prepareCall(query);
			csmt.setInt(1, Integer.parseInt(receiptBookDetails.getReceiptBookNumber().trim()));
			csmt.setInt(2, Integer.parseInt(receiptBookDetails.getReceiptBookStartSequenceNumber().trim()));
			csmt.setInt(3, Integer.parseInt(receiptBookDetails.getReceiptBookEndSequenceNumber().trim()));
			csmt.registerOutParameter(4, java.sql.Types.INTEGER);
			csmt.registerOutParameter(5, java.sql.Types.INTEGER);
			csmt.registerOutParameter(6, java.sql.Types.INTEGER);
			csmt.executeQuery();
//			System.out.println(csmt.getInt(4)+" : "+csmt.getInt(5)+" : "+csmt.getInt(6));
			/*if(csmt.getInt(4)!=0)
				status = "Duplicacy Receipt Book";
			if(csmt.getInt(5)!=0)
				status += "##Duplicate Start Sequence";
			if(csmt.getInt(6)!=0)
				status += "##Duplicate End Sequence";*/
			if(csmt.getInt(4)!=0 || csmt.getInt(5)!=0 || csmt.getInt(6)!=0)
				status = "DuplicacyFound";
		}
		catch(SQLException s14){
			s14.printStackTrace();
			System.out.println("exception in checkReceiptBookDuplicacy method : "+s14.getMessage());
		}
		return status;
	}
	
	@SuppressWarnings("unchecked")
	public JSONArray getReceiptBookMaster()throws SQLException{
		JSONArray jsonArray = new JSONArray();
		JSONObject jsonObject = null;
		String query = "select RECEIPT_BOOK_NUMBER,START_SEQUENCE_NUMBER,END_SEQUENCE_NUMBER "+
					   " from EBR_RECEIPT_BOOK_MASTER order by RECEIPT_BOOK_NUMBER";
		try{
			con = DatabaseManager.getConnection();
			psmt = con.prepareStatement(query);
			rs = psmt.executeQuery();
			while(rs.next()){
				jsonObject = new JSONObject();
				jsonObject.put("RECEIPT_BOOK_NUMBER", rs.getInt("RECEIPT_BOOK_NUMBER"));
				jsonObject.put("START_SEQUENCE_NUMBER", rs.getInt("START_SEQUENCE_NUMBER"));
				jsonObject.put("END_SEQUENCE_NUMBER", rs.getInt("END_SEQUENCE_NUMBER"));
				jsonArray.add(jsonObject);
			}
		}
		catch(SQLException s15){
			s15.printStackTrace();
			System.out.println("Exception in getReceiptBookMaster method : "+s15.getMessage());
		}
		finally{
			DatabaseManager.closeAllConnection(con, psmt, rs);
		}
		return jsonArray;
	}
	
	@SuppressWarnings("unchecked")
	public JSONArray getStartEndSequencesByReceiptBookNumber(String receiptBookNumber)throws SQLException{
		JSONArray jsonArray = new JSONArray();
		JSONObject jsonObject = null;
		String query = "select START_SEQUENCE_NUMBER, END_SEQUENCE_NUMBER from EBR_RECEIPT_BOOK_MASTER where RECEIPT_BOOK_NUMBER="+receiptBookNumber.trim();
		try{
			con = DatabaseManager.getConnection();
			psmt = con.prepareStatement(query);
			rs = psmt.executeQuery();
			while(rs.next()){
				jsonObject = new JSONObject();
				jsonObject.put("START_SEQUENCE_NUMBER", rs.getInt("START_SEQUENCE_NUMBER"));
				jsonObject.put("END_SEQUENCE_NUMBER", rs.getInt("END_SEQUENCE_NUMBER"));
				jsonArray.add(jsonObject);
			}
		}
		catch(SQLException s16){
			s16.printStackTrace();
			System.out.println("Exception in getStartEndSequencesByReceiptBookNumber method : "+s16.getMessage());
		}
		finally{
			DatabaseManager.closeAllConnection(con, psmt, rs);
		}
		return jsonArray;
	}
	
	@SuppressWarnings("unchecked")
	public JSONArray getLeafDetails(String receiptBookNumber)throws SQLException{
		JSONArray jsonArray = new JSONArray();
		JSONObject jsonObject = null;
		String query = "select * from EBR_LEAF_DETAILS_MASTER where RECEIPT_BOOK_NUMBER='"+receiptBookNumber.trim()+"'";
		try{
			con = DatabaseManager.getConnection();
			psmt = con.prepareStatement(query);
			rs = psmt.executeQuery();
			while(rs.next()){
				jsonObject = new JSONObject();
				jsonObject.put("SLIP_NUMBER", rs.getString("SLIP_NUMBER"));
				jsonObject.put("LAN", rs.getString("LAN"));
				jsonObject.put("CUSTOMER_NAME", rs.getString("CUSTOMER_NAME"));
				jsonObject.put("PAYMENT_MODE", rs.getString("PAYMENT_MODE"));
				jsonObject.put("AMOUNT", rs.getString("AMOUNT"));
				jsonObject.put("STATUS", rs.getString("STATUS"));
				jsonArray.add(jsonObject);
			}		
		}
		catch(SQLException s17){
			s17.printStackTrace();
			System.out.println("Exception in getStartEndSequencesByReceiptBookNumber method : "+s17.getMessage());
		}
		finally{
			DatabaseManager.closeAllConnection(con, psmt, rs);
		}
		return jsonArray;
	}
	
	public int submitLeafLostDetails(ReceiptBookDetails receiptBookDetails, String lostType, String reasonOfLost) throws SQLException{
		int status = 0;
		String query = "insert into EBR_LOST_DETAILS(ID,TXID,RECEIPT_BOOK_NUMBER,LEAF_NUMBER,LOST_TYPE,REASON_OF_LOST)"+ 
					   " values((SELECT NVL(MAX(ID),0)+1 FROM EBR_LOST_DETAILS),?,?,?,?,?)";
		try{
			con = DatabaseManager.getConnection();
			psmt = con.prepareStatement(query);
			psmt.setString(1, receiptBookDetails.getTxId());
			psmt.setString(2, receiptBookDetails.getReceiptBookNumber());
			psmt.setString(3, receiptBookDetails.getReceiptBookStartSequenceNumber());
			psmt.setString(4, lostType);
			psmt.setString(5, reasonOfLost);
			status = psmt.executeUpdate();
		}
		catch(SQLException s18){
			s18.printStackTrace();
			System.out.println("Exception in submitLeafLostDetails method : "+s18.getMessage());
		}
		finally{
			DatabaseManager.close(con, psmt);
		}
		return status;
	}
	
	@SuppressWarnings("unchecked")
	public JSONArray getAgencyList()throws SQLException{
		JSONArray jsonArray = new JSONArray();
		JSONObject jsonObject = null;
		String query = "select VENDOR_CODE,VENDOR_NAME,OPERATING_CITY from EBR_AGENCY_MASTER where STATUS like '%LIVE%'";
		try{
			con = DatabaseManager.getConnection();
			psmt = con.prepareStatement(query);
			rs = psmt.executeQuery();
			while(rs.next()){
				jsonObject = new JSONObject();
				jsonObject.put("VENDOR_CODE", rs.getString("VENDOR_CODE"));
				jsonObject.put("VENDOR_NAME", rs.getString("VENDOR_NAME"));
				jsonObject.put("OPERATING_CITY", rs.getString("OPERATING_CITY"));
				jsonArray.add(jsonObject);
			}
		}
		catch(SQLException s19){
			s19.printStackTrace();
			System.out.println("Exception in getAgencyList method : "+s19.getMessage());
		}
		finally{
			DatabaseManager.closeAllConnection(con, psmt, rs);
		}
		return jsonArray;
	}

	public static void main(String[] args) throws SQLException, ParseException {
		System.out.println(ReceiptBookingUtilities.getInstance().getAgencyList());
	}
}
