package com.rcf.ebr.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Hashtable;

import javax.naming.Context;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;

import com.rcf.ebr.db.DatabaseManager;

public class AuthenticationUtils {
	private Connection con = null;
	private PreparedStatement psmt = null;
	private PreparedStatement psmt2 = null;
	private ResultSet rs = null;
	private ResultSet rs2 = null;
	private static AuthenticationUtils authenticationUtils;
	
	public static synchronized AuthenticationUtils getInstance(){
		if(authenticationUtils==null)
			authenticationUtils = new AuthenticationUtils();
		
		return authenticationUtils;
	}
	
	/**
	 * @author Narayan
	 * @param sapId
	 * @param password
	 * @return a flag that provide information that the user exists or not in AD.
	 */
	public boolean isUserCredentialsValidInAD(String sapId, String password) {
		boolean b = false;
		Hashtable<Object, Object> env = new Hashtable<Object,Object>(11);
		if (sapId != null && password != null) {
			env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
			env.put(Context.PROVIDER_URL, "ldap://10.65.1.53:389");
			env.put(Context.SECURITY_AUTHENTICATION, "simple");
			env.put(Context.SECURITY_PRINCIPAL, sapId + "@RELIANCECAPITAL");
			env.put(Context.SECURITY_CREDENTIALS, password);
			try {
				DirContext ctx = new InitialDirContext(env);
				b = true;
				ctx.close();
			} catch (Exception e) {
				b = false;
				System.out.println("Exception Occur in checkUserInAD() Error code : " + e.getMessage());
			}
		}
		return b;
	}
	
	/**
	 * @author Narayan
	 * @param sapid
	 * @return user info about HO or CM
	 * @throws SQLException
	 */
	public String getUserInfoForAuthorization(String sapid) throws SQLException{
		String userInfo = "";
		String query = "select * from RCF_EMPLOYEE where (UPPER(department) LIKE '%COLLECTION%' or "+
						" UPPER(department) LIKE '%SALES%' or UPPER(department) LIKE '%S'||'&'||'D%' or"+
						" UPPER(department) LIKE '%OPERATION%') and upper(status) like '%ACTIVE%'"+
					   " and upper(employee_sapid)=upper('"+sapid.trim()+"')";
		String queryForHO = "select * from ebr_ho_master where upper(sapid)=upper('"+sapid.trim()+"')";
		try{
			con = DatabaseManager.getConnection();
			psmt = con.prepareStatement(queryForHO);
			rs = psmt.executeQuery();
			if(rs.next()){
				userInfo = "HO";
			}
			else{
				psmt2 = con.prepareStatement(query);
				rs2 = psmt2.executeQuery();
				if(rs2.next()){
					userInfo = "CM";
				}
				else{
					userInfo = "User Not Exists";
				}
				//userInfo = "CM";
			}
		}
		catch(SQLException s){
			s.printStackTrace();
		}
		finally{
			DatabaseManager.closeAllConnection(con, psmt, rs);
		}
		return userInfo;
	}
	

	
	public static void main(String[] args) throws SQLException {
		System.out.println(AuthenticationUtils.getInstance().getUserInfoForAuthorization("70013368"));
	}

}
