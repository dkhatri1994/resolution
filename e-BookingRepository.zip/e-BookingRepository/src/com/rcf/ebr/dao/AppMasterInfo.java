package com.rcf.ebr.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.rcf.ebr.bean.EmployeeDetails;
import com.rcf.ebr.db.DatabaseManager;

public class AppMasterInfo {
	private Connection con = null;
	private PreparedStatement psmt = null;
	private ResultSet rs = null;
	
	private static AppMasterInfo appMasterInfo;
	
	public static synchronized AppMasterInfo getInstance(){
		if(appMasterInfo==null)
			appMasterInfo = new AppMasterInfo();
		
		return appMasterInfo;
	}
	
	public EmployeeDetails getEmployeeInfo(String sapid)throws SQLException{
		EmployeeDetails empDetails = new EmployeeDetails();
		String query = "select employee_sapid,first_name,last_name,e_mail,reporting_manager,mobile_no,"+
				" designation,location,functional_manager,product,department,status from "+
				" RCF_EMPLOYEE where upper(employee_sapid)=upper('"+sapid.trim()+"')";
		try{
			con = DatabaseManager.getConnection();
			psmt = con.prepareStatement(query);
			rs = psmt.executeQuery();
			while(rs.next()){
				empDetails.setSapid(rs.getString("employee_sapid"));
				empDetails.setFirstName(rs.getString("first_name"));
				empDetails.setLastName(rs.getString("last_name"));
				empDetails.setEmail(rs.getString("e_mail"));
				empDetails.setReportingManager(rs.getString("reporting_manager"));
				empDetails.setMobileNumber(rs.getString("mobile_no"));
				empDetails.setDesignation(rs.getString("designation"));
				empDetails.setLocation(rs.getString("location"));
				empDetails.setFunctionalManager(rs.getString("functional_manager"));
				empDetails.setProduct(rs.getString("product"));
				empDetails.setDepartment(rs.getString("department"));
				empDetails.setStatus(rs.getString("status"));
			}
		}
		catch(SQLException s){
			s.printStackTrace();
			System.out.println("Exception in getEmployeeInfo method : "+s.getMessage());
		}
		finally{
			DatabaseManager.closeAllConnection(con, psmt, rs);
		}
		return empDetails;
	}
	
	public static void main(String[] args)throws SQLException {
		System.out.println(AppMasterInfo.getInstance().getEmployeeInfo("narayanc").getDepartment());
	}
}
