package com.rcf.ebr.bean;

import javax.sql.DataSource;

public class ReceiptBookAndCourierDetails {
	private String txId;
	private int availableReceiptQuantity;
	private int receiptsForAdjustment;
	private String courierAgencyName;
	private String courierContactNumber;
	private String courierSendingDate;
	private String expectedDeliveryDate;
	private String address;
	private String receiptBookIssuedBy;
	private String receiptBookIssueTime;
	private String isConfirm;	
	
	private String recCourierAgencyName;
	private String recCourierContactNumber;
	private String recCourierReceiveDate;
	
	
	public String getRecCourierAgencyName() {
		return recCourierAgencyName;
	}
	public void setRecCourierAgencyName(String recCourierAgencyName) {
		this.recCourierAgencyName = recCourierAgencyName;
	}
	public String getRecCourierContactNumber() {
		return recCourierContactNumber;
	}
	public void setRecCourierContactNumber(String recCourierContactNumber) {
		this.recCourierContactNumber = recCourierContactNumber;
	}
	public String getRecCourierReceiveDate() {
		return recCourierReceiveDate;
	}
	public void setRecCourierReceiveDate(String recCourierReceiveDate) {
		this.recCourierReceiveDate = recCourierReceiveDate;
	}
	private DataSource dataSource;
//	Worksteps
	private String workStep;
	private String nextWorkStep;
	public String getWorkStep() {
		return workStep;
	}
	public void setWorkStep(String workStep) {
		this.workStep = workStep;
	}
	public String getNextWorkStep() {
		return nextWorkStep;
	}
	public void setNextWorkStep(String nextWorkStep) {
		this.nextWorkStep = nextWorkStep;
	}
	public String getTxId() {
		return txId;
	}
	public void setTxId(String txId) {
		this.txId = txId;
	}
	public int getAvailableReceiptQuantity() {
		return availableReceiptQuantity;
	}
	public void setAvailableReceiptQuantity(int availableReceiptQuantity) {
		this.availableReceiptQuantity = availableReceiptQuantity;
	}
	public int getReceiptsForAdjustment() {
		return receiptsForAdjustment;
	}
	public void setReceiptsForAdjustment(int receiptsForAdjustment) {
		this.receiptsForAdjustment = receiptsForAdjustment;
	}
	public String getCourierAgencyName() {
		return courierAgencyName;
	}
	public void setCourierAgencyName(String courierAgencyName) {
		this.courierAgencyName = courierAgencyName;
	}
	public String getCourierContactNumber() {
		return courierContactNumber;
	}
	public void setCourierContactNumber(String courierContactNumber) {
		this.courierContactNumber = courierContactNumber;
	}
	public String getCourierSendingDate() {
		return courierSendingDate;
	}
	public void setCourierSendingDate(String courierSendingDate) {
		this.courierSendingDate = courierSendingDate;
	}
	public String getExpectedDeliveryDate() {
		return expectedDeliveryDate;
	}
	public void setExpectedDeliveryDate(String expectedDeliveryDate) {
		this.expectedDeliveryDate = expectedDeliveryDate;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getReceiptBookIssuedBy() {
		return receiptBookIssuedBy;
	}
	public void setReceiptBookIssuedBy(String receiptBookIssuedBy) {
		this.receiptBookIssuedBy = receiptBookIssuedBy;
	}
	public String getReceiptBookIssueTime() {
		return receiptBookIssueTime;
	}
	public void setReceiptBookIssueTime(String receiptBookIssueTime) {
		this.receiptBookIssueTime = receiptBookIssueTime;
	}
	public String getIsConfirm() {
		return isConfirm;
	}
	public void setIsConfirm(String isConfirm) {
		this.isConfirm = isConfirm;
	}
	public DataSource getDataSource() {
		return dataSource;
	}
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}
	
	
}
