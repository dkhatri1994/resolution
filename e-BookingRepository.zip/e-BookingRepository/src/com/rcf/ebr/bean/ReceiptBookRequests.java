package com.rcf.ebr.bean;

import javax.sql.DataSource;

public class ReceiptBookRequests {
	private String txId;
	private int receiptQuantity;
	private String requestedBy;
	private String requestedTime;
	private String requestLetter;
	private String requestName;
	private String requestStatus;
	
//	Worksteps
	private String workStep;
	private String nextWorkStep;
	
//	DataSource
	private DataSource dataSource;
	
	public String getTxId() {
		return txId;
	}
	public void setTxId(String txId) {
		this.txId = txId;
	}
	public int getReceiptQuantity() {
		return receiptQuantity;
	}
	public void setReceiptQuantity(int receiptQuantity) {
		this.receiptQuantity = receiptQuantity;
	}
	public String getRequestedBy() {
		return requestedBy;
	}
	public void setRequestedBy(String requestedBy) {
		this.requestedBy = requestedBy;
	}
	public String getRequestedTime() {
		return requestedTime;
	}
	public void setRequestedTime(String requestedTime) {
		this.requestedTime = requestedTime;
	}
	public String getRequestLetter() {
		return requestLetter;
	}
	public void setRequestLetter(String requestLetter) {
		this.requestLetter = requestLetter;
	}
	public String getRequestName() {
		return requestName;
	}
	public void setRequestName(String requestName) {
		this.requestName = requestName;
	}
	public String getRequestStatus() {
		return requestStatus;
	}
	public void setRequestStatus(String requestStatus) {
		this.requestStatus = requestStatus;
	}
	public String getWorkStep() {
		return workStep;
	}
	public void setWorkStep(String workStep) {
		this.workStep = workStep;
	}
	public String getNextWorkStep() {
		return nextWorkStep;
	}
	public void setNextWorkStep(String nextWorkStep) {
		this.nextWorkStep = nextWorkStep;
	}
	public DataSource getDataSource() {
		return dataSource;
	}
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}
	
}
