package com.rcf.ebr.bean;

import javax.sql.DataSource;

public class ReceiptBookDetails {
	private String txId;
	private String receiptBookNumber;
	private String receiptBookStartSequenceNumber;
	private String receiptBookEndSequenceNumber;
	
//	DataSource
	private DataSource dataSource;

	public String getTxId() {
		return txId;
	}

	public void setTxId(String txId) {
		this.txId = txId;
	}

	public String getReceiptBookNumber() {
		return receiptBookNumber;
	}

	public void setReceiptBookNumber(String receiptBookNumber) {
		this.receiptBookNumber = receiptBookNumber;
	}

	public String getReceiptBookStartSequenceNumber() {
		return receiptBookStartSequenceNumber;
	}

	public void setReceiptBookStartSequenceNumber(String receiptBookStartSequenceNumber) {
		this.receiptBookStartSequenceNumber = receiptBookStartSequenceNumber;
	}

	public String getReceiptBookEndSequenceNumber() {
		return receiptBookEndSequenceNumber;
	}

	public void setReceiptBookEndSequenceNumber(String receiptBookEndSequenceNumber) {
		this.receiptBookEndSequenceNumber = receiptBookEndSequenceNumber;
	}

	public DataSource getDataSource() {
		return dataSource;
	}

	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}

//	Getters / Setters
	
}
