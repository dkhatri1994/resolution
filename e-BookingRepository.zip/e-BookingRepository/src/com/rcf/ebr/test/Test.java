package com.rcf.ebr.test;

import java.io.File;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class Test {
	
	
	public static void main(String[] args) throws ParseException {
		/*File file = new File("D:/Users/NarayanC/Desktop/hs_err_pid3340.log");
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
		System.out.println("Pehle Wali : "+sdf.format(file.lastModified()));
		String newModifyDate = "21-07-2018";
		Date dt = sdf.parse(newModifyDate);
		file.setLastModified(dt.getTime());
		System.out.println("Nayi Wali : "+sdf.format(file.lastModified()));
		*/
		
		
		String key[]={"Absd","Bsdhsjdhsjd","Chudnfjdfnkdfdkfdlfkdl"};
		String val[]={"121212121","34343344","65656565"};
		for(int i=0;i<key.length && i<val.length;i++){
			int diff=40-key[i].length();
			String str = "";
			for(int j=0;j<diff;j++)
				str += " ";
			System.out.println(key[i]+str+val[i]);
		}
	}
}
