package com.rcf.ebr.test;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

/**
 * Servlet implementation class TestServlet
 */
@WebServlet("/TestServ.jsf")
public class TestServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		out.print("<html><body>");
		out.print("<h3>Hello Naru ...Connection Pooling testing</h3>");
		out.print("</body></html>"); 
		String query = "select * from EBR_RECEIPT_BOOK_DETAILS";
		try {/*
			Context initContext = new InitialContext();
			Context envContext =(Context) initContext.lookup("java:comp/env");
			DataSource ds =(DataSource) envContext.lookup("jdbc/MyUatDB");
			Connection con = ds.getConnection();
			PreparedStatement ps = con.prepareStatement(query);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				out.println(rs.getString(1));
			}
		*/}
		catch (Exception e) {
			e.printStackTrace();
		}
		
	}



}
