package com.rcf.ebr.comments;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import com.rcf.ebr.db.DatabaseManager;

public class EbrComments 
{
	Connection con = null;
	CallableStatement csmt = null;
	PreparedStatement pst = null;
	ResultSet rs = null;
	private static EbrComments brtComments;
	public static synchronized EbrComments getInstance(){
		if(brtComments==null)
			brtComments = new EbrComments();
		
		return brtComments;
	}
	
	public int add_New_Comment(String txId, String comment_On, String comment_By, String comment, String performer_sapid)
    {
        String success = null;
        String query = null;
        int serial_p = 0;
        try
        {
            query = "{call EBR_PROCEDURE_COMMENT_DETAILS(?,?,?,?,?,?,?)}";
            con = DatabaseManager.getConnection();
            csmt = con.prepareCall(query);
            csmt.setInt(1, 0);
            csmt.setString(2, txId);
            csmt.setString(3, comment_On);
            csmt.setString(4, comment_By);
            csmt.setString(5, comment);
            csmt.setString(6, performer_sapid);
            csmt.registerOutParameter(7, 2); //2nd parameter is size in byte of out param
            int rst = csmt.executeUpdate();
            serial_p = csmt.getInt(7);
            if(1 == rst)
                success = "Comment is Added Successfully";
            else
                success = "Problem in Add Comment";
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
        finally
        {
        	DatabaseManager.closeDBConnection(con);
        }
        return serial_p;
    }
	
	public int update_Comment(int Serial_No, int txId, String commented_on, String commented_by, String comment, String performer_sapid)
    {
        PreparedStatement pst = null;
        String query = null;
        try
        {
            query ="Update EBR_COMMENT_DETAILS SET SERIAL_NO='"+Serial_No+"',TXID='"+txId+"',COMMENTED_ON='"+commented_on+"',COMMENTED_BY='"+commented_by+"',COMMENTS='"+comment+"',PERFORMER_SAPID='"+performer_sapid+"' where SERIAL_NO='"+Serial_No+"'";
            con = DatabaseManager.getConnection();
            pst = con.prepareStatement(query);
            int rst = pst.executeUpdate();
            if(1 == rst)
                System.out.println("data is updated");
            else
                System.out.println("not edited");
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
        finally
        {
        	DatabaseManager.closeDBConnection(con);
        }
        return Serial_No;
    }
	
	@SuppressWarnings("unchecked")
	public JSONArray getComments(String txId)
	{
		JSONArray jsonArray = new JSONArray();
		JSONObject jsonObj = null;
		String query = "select * from EBR_COMMENT_DETAILS where TXID='"+txId.trim()+"' order by COMMENTED_ON";
		try
		{	
			con = DatabaseManager.getConnection();
			pst = con.prepareStatement(query);
			rs = pst.executeQuery();
			while(rs.next())
			{
				jsonObj = new JSONObject();
				jsonObj.put("sno", rs.getInt("SNO"));
				jsonObj.put("txId", rs.getString("TXID"));
				jsonObj.put("commentedOn", rs.getString("COMMENTED_ON"));
				jsonObj.put("commentedBy", rs.getString("COMMENTED_BY"));
				jsonObj.put("comment", rs.getString("COMMENTS"));
				jsonObj.put("sapid", rs.getString("PERFORMER_SAPID"));
				jsonArray.add(jsonObj);
			}
		}
		catch(SQLException se)
		{
			se.printStackTrace();
			System.out.println("exception in getComment method : "+se.getMessage());
		}
		
		return jsonArray;
	}
	
	public static void main(String[] args) {
		EbrComments obj = new EbrComments();
		System.out.println(obj.getComments("31183"));
	}
}
