package com.rcf.ebr.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.text.ParseException;

import javax.annotation.Resource;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import org.json.simple.JSONArray;
import com.rcf.ebr.bean.ReceiptBookAndCourierDetails;
import com.rcf.ebr.bean.ReceiptBookDetails;
import com.rcf.ebr.comments.EbrComments;
import com.rcf.ebr.dao.ReceiptBookingUtilities;

/**
 * Servlet implementation class AppController
 */
@WebServlet("/AppController/*")
public class AppController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	/*@Resource(name="jdbc/MyUatDB")
	private DataSource dataSource;*/

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			String uri = request.getRequestURI();
			String action = uri.substring(uri.lastIndexOf("/") + 1);
			if(action.equals("requestReceiptBook"))
				requestReceiptBook(request,response);
			else if(action.equals("getReceiptBookRequests"))
				getReceiptBookRequests(request, response);
			else if(action.equals("getRequesterDetails"))
				getRequesterDetails(request, response);
			else if(action.equals("saveReceiptAndCourierDetails"))
				saveReceiptAndCourierDetails(request, response);
			else if(action.equals("getReceiptBookAndCourierDetails"))
				getReceiptBookAndCourierDetails(request,response);
			else if(action.equals("confirmReceiptAndCourierDetails"))
				confirmReceiptAndCourierDetails(request, response);
			else if(action.equals("getDashBoardCounts"))
				getDashBoardCounts(request,response);//getDashBoardCounts(request,response,dataSource);
			else if(action.equals("getAllRequestDetails"))
				getAllRequestDetails(request,response);
			else if(action.equals("getAllReceiptBooks"))
				getAllReceiptBooks(request,response);
			else if(action.equals("saveLeafData"))
				saveLeafData(request,response);
			else if(action.equals("validationCounts"))
				validationCounts(request,response);
			else if(action.equals("sentReceiptBooksToHO"))
				sentReceiptBooksToHO(request,response);
			else if(action.equals("addComment"))
				addComment(request,response);
			else if(action.equals("showComments"))
				showComments(request,response);
			else if(action.equals("addNewReceiptBook"))
				addNewReceiptBook(request,response);
			else if(action.equals("getReceiptBookMaster"))
				getReceiptBookMaster(request,response);
			else if(action.equals("getStartEndSequencesByReceiptBookNumber"))
				getStartEndSequencesByReceiptBookNumber(request,response);
			else if(action.equals("getLeafDetails"))
				getLeafDetails(request,response);
			else if(action.equals("submitLeafLostDetails"))
				submitLeafLostDetails(request,response);
			else if(action.equals("getAgencyList"))
				getAgencyList(request,response);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Exception in AppController : " + e.getMessage());
		}
	}
	
	public void requestReceiptBook(HttpServletRequest request, HttpServletResponse response)throws IOException,SQLException{
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		String receiptQuantity = request.getParameter("receiptQuantity");
		String requestLetter = request.getParameter("requestLetter");
		String requestTime = request.getParameter("requestTime");
		String requestedBy = request.getParameter("requestedBy");
		String requestName = request.getParameter("requestName");
		String workStep = request.getParameter("workStep");
		String nextWorkStep = request.getParameter("nextWorkStep");
		String location = request.getParameter("location");
		int status = ReceiptBookingUtilities.getInstance().requestReceiptBooks(receiptQuantity, requestLetter, requestedBy,requestName, requestTime, workStep, nextWorkStep,location);
		out.println(status);
		out.close();
	}
	
	public void getReceiptBookRequests(HttpServletRequest request, HttpServletResponse response)throws IOException, SQLException, ParseException{
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		String workstep = request.getParameter("workStep");
		String type = request.getParameter("type");
		String loggedInUser = request.getParameter("loggedInUser");
		JSONArray jsonArray = ReceiptBookingUtilities.getInstance().getReceiptBookRequests(workstep,type,loggedInUser);
		out.println(jsonArray);
		out.close();
	}
	
	public void getRequesterDetails(HttpServletRequest request, HttpServletResponse response)throws IOException,SQLException{
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		String txId = request.getParameter("txId");
		JSONArray jsonArray = ReceiptBookingUtilities.getInstance().getRequesterDetails(txId);
		out.println(jsonArray);
		out.close();
	}
	
	public void saveReceiptAndCourierDetails(HttpServletRequest request, HttpServletResponse response)throws IOException,SQLException{
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		String availableReceipts = request.getParameter("availableReceipts");
		String courierAgencyName = request.getParameter("courierAgencyName");
		String courierContactNumber = request.getParameter("courierContactNumber");
		String courierDispatchDate = request.getParameter("courierDispatchDate");
		String expectedDeliveryDate = request.getParameter("expectedDeliveryDate");
		String courierAddress = request.getParameter("courierAddress");
		String receiptsForAdjustment = request.getParameter("receiptsForAdjustment");
		String receiptBookData = request.getParameter("receiptBookData");
		String txId = request.getParameter("txId");
		String loggedInUser = request.getParameter("loggedInUser");
		String receiptBookIssueTime = request.getParameter("receiptBookIssueTime");
		String saveStatus = ReceiptBookingUtilities.getInstance().saveReceiptAndCourierDetails(availableReceipts, courierAgencyName, courierContactNumber, courierDispatchDate, expectedDeliveryDate, courierAddress, receiptsForAdjustment, receiptBookData, txId,loggedInUser,receiptBookIssueTime);
		out.println(saveStatus);
		out.close();
	}
	
	public void getReceiptBookAndCourierDetails(HttpServletRequest request, HttpServletResponse response)throws IOException,SQLException
	{
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		String txId = request.getParameter("txId");
		String res = ReceiptBookingUtilities.getInstance().getReceiptBookAndCourierDetails(txId);
		out.println(res);
		out.close();
	}
	
	public void confirmReceiptAndCourierDetails(HttpServletRequest request,HttpServletResponse response)throws IOException,SQLException
	{
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		ReceiptBookAndCourierDetails courierDetails = new ReceiptBookAndCourierDetails();
		courierDetails.setTxId(request.getParameter("txId"));
		courierDetails.setRecCourierAgencyName(request.getParameter("recCourierAgencyName"));
		courierDetails.setRecCourierContactNumber(request.getParameter("recCourierContactNumber"));
		courierDetails.setRecCourierReceiveDate(request.getParameter("recCourierReceiveDate"));

		int isConfirmed = ReceiptBookingUtilities.getInstance().confirmReceiptAndCourierDetails(courierDetails);
		out.println(isConfirmed);
		out.close();
	}
	/**
	 * @author Narayan
	 * @param request
	 * @param response
	 * @param dataSource
	 * @throws IOException
	 * @throws SQLException
	 * @see Below commented code was tested for using datasource which is accurate and running code > Test Successful 
	 */
	/*public void getDashBoardCounts(HttpServletRequest request,  HttpServletResponse response, DataSource dataSource) throws IOException,SQLException
	{
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		String workstep = request.getParameter("workStep");
		String type = request.getParameter("type");
		String loggedInUser = request.getParameter("loggedInUser");
		int count = ReceiptBookingUtilities.getInstance().getCountsForDashboard(dataSource.getConnection(), workstep, type,loggedInUser);
		out.println(count);
		out.close();
	}*/
	public void getDashBoardCounts(HttpServletRequest request,  HttpServletResponse response) throws IOException,SQLException
	{
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		String workstep = request.getParameter("workStep");
		String type = request.getParameter("type");
		String loggedInUser = request.getParameter("loggedInUser");
		int count = ReceiptBookingUtilities.getInstance().getCountsForDashboard(workstep, type,loggedInUser);
		out.println(count);
		out.close();
	}
	
	public void getAllRequestDetails(HttpServletRequest request, HttpServletResponse response) throws IOException,SQLException, ParseException
	{
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		String fromDate = request.getParameter("fromDate");
		String toDate = request.getParameter("toDate");
		String location = request.getParameter("location");
		JSONArray jsonArray = ReceiptBookingUtilities.getInstance().getAllRequestsWithFilters(fromDate, toDate, location);
		out.println(jsonArray);
		out.close();
	}
	
	public void getAllReceiptBooks(HttpServletRequest request, HttpServletResponse response)throws IOException,SQLException{
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		String loggedInUser = request.getParameter("loggedInUser");
		String workstep = request.getParameter("workstep");
		JSONArray jsonArray = ReceiptBookingUtilities.getInstance().getAllReceiptBooks(loggedInUser,workstep);
		out.println(jsonArray);
		out.close();
	}
	public void saveLeafData(HttpServletRequest request, HttpServletResponse response) throws IOException,SQLException{
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		String receiptBookNumber = request.getParameter("receiptBookNumber");
		String leafData = request.getParameter("leafData");
		ReceiptBookingUtilities.getInstance().saveLeafData(receiptBookNumber,leafData);
//		out.println(isSaved);
		out.close();
	}
	public void validationCounts(HttpServletRequest request, HttpServletResponse response) throws IOException,SQLException{
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		String workStep = request.getParameter("workStep");
		String queryType = request.getParameter("queryType");
		String receiptBookNumber = request.getParameter("receiptBookNumber");
		String status = ReceiptBookingUtilities.getInstance().validationCounts(workStep, queryType, receiptBookNumber);
		out.println(status);
		out.close();
	}
	public void sentReceiptBooksToHO(HttpServletRequest request, HttpServletResponse response)throws SQLException{
//		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		String selectedReceiptBooks = request.getParameter("selectedReceiptBooks");
		String courierDetails = request.getParameter("courierDetails");
		ReceiptBookingUtilities.getInstance().sentReceiptBooksToHO(selectedReceiptBooks,courierDetails);
	}
	public void addComment(HttpServletRequest request, HttpServletResponse response)throws IOException {

		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		String loggedInUser = request.getParameter("loggedInUser");
		String userName = request.getParameter("userName");
		String comment = request.getParameter("comment");
		String commentOn = request.getParameter("commentOn");
		String txId = request.getParameter("txId");

//		BRTComments brtComments = new BRTComments();
		int sno = EbrComments.getInstance().add_New_Comment(txId, commentOn, userName, comment, loggedInUser);
		out.println(sno);
		out.close();
	
	}
	public void showComments(HttpServletRequest request, HttpServletResponse response) throws IOException {
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		String txId = request.getParameter("txId");

//		BRTComments brtComments = new BRTComments();
		JSONArray jsonArray = EbrComments.getInstance().getComments(txId);
		out.println(jsonArray);
		out.close();
	}
	public void addNewReceiptBook(HttpServletRequest request,HttpServletResponse response)throws IOException,SQLException{
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		ReceiptBookDetails receiptBookDetails = new ReceiptBookDetails();
		receiptBookDetails.setReceiptBookNumber(request.getParameter("receiptNumber"));
		receiptBookDetails.setReceiptBookStartSequenceNumber(request.getParameter("startSequenceNumber"));
		receiptBookDetails.setReceiptBookEndSequenceNumber(request.getParameter("endSequenceNumber"));
		int status = ReceiptBookingUtilities.getInstance().addNewReceiptBook(receiptBookDetails);
		out.println(status);
		out.close();
	}
	
	public void getReceiptBookMaster(HttpServletRequest request, HttpServletResponse response)throws IOException,SQLException{
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		JSONArray jsonArray = ReceiptBookingUtilities.getInstance().getReceiptBookMaster();
		out.println(jsonArray);
		out.close();
	}
	public void getStartEndSequencesByReceiptBookNumber(HttpServletRequest request, HttpServletResponse response)throws IOException,SQLException{
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		JSONArray jsonArray = ReceiptBookingUtilities.getInstance().getStartEndSequencesByReceiptBookNumber(request.getParameter("receiptBookNumber"));
		out.println(jsonArray);
		out.close();
	}
	public void getLeafDetails(HttpServletRequest request,HttpServletResponse response)throws IOException,SQLException
	{
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		String receiptBookNumber = request.getParameter("receiptBookNumber");
		JSONArray jsonArray = ReceiptBookingUtilities.getInstance().getLeafDetails(receiptBookNumber);
		out.println(jsonArray);
		out.close();
	}
	public void submitLeafLostDetails(HttpServletRequest request, HttpServletResponse response) throws IOException, SQLException{
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		ReceiptBookDetails receiptBookDetails = new ReceiptBookDetails();
		receiptBookDetails.setTxId(request.getParameter("txId"));
		receiptBookDetails.setReceiptBookNumber(request.getParameter("receiptBookNumber"));
		receiptBookDetails.setReceiptBookStartSequenceNumber(request.getParameter("leafNumber"));
		String lostType = request.getParameter("lostType");
		String reasonOfLostleaf = request.getParameter("reasonOfLostleaf");
		int status = ReceiptBookingUtilities.getInstance().submitLeafLostDetails(receiptBookDetails, lostType, reasonOfLostleaf);
		out.println(status);
		out.close();
	}
	public void getAgencyList(HttpServletRequest request, HttpServletResponse response) throws IOException,SQLException
	{
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		JSONArray jsonArray = ReceiptBookingUtilities.getInstance().getAgencyList();
		out.println(jsonArray);
	}
}
