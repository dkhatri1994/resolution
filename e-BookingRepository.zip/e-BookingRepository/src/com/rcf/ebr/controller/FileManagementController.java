package com.rcf.ebr.controller;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.util.ResourceBundle;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class FileManagementController
 */
@WebServlet("/FileManagementController/*")
public class FileManagementController extends HttpServlet {
	ResourceBundle resourceBundle = null;
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			String uri = request.getRequestURI();
			String action = uri.substring(uri.lastIndexOf("/") + 1);
			if (action.equals("uploadRequestLetter"))
				uploadRequestLetter(request, response);
			else if(action.equals("downloadRequestLetter"))
				downloadRequestLetter(request, response);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Exception in FileManagementController > " + e.getMessage());
		}
	}

	public void uploadRequestLetter(HttpServletRequest request, HttpServletResponse response) throws IOException {

		PrintWriter out = response.getWriter();
		resourceBundle = ResourceBundle.getBundle("DBInfo");
		String uploadFolder = resourceBundle.getString("upload-files-folder");
		System.out.println("upload folder : " + uploadFolder);
		System.out.println("context path : " + request.getContextPath());
		response.setContentType("text/html");
		String saveFile = "";
		String contentType = request.getContentType();
		// System.out.println("contentType "+contentType);

		if ((contentType != null) && (contentType.indexOf("multipart/form-data") >= 0)) {
			DataInputStream in = new DataInputStream(request.getInputStream());
			int formDataLength = request.getContentLength();
			byte dataBytes[] = new byte[formDataLength];
			int byteRead = 0;
			int totalBytesRead = 0;
			while (totalBytesRead < formDataLength) {
				byteRead = in.read(dataBytes, totalBytesRead, formDataLength);
				totalBytesRead += byteRead;
			}
			String file = new String(dataBytes);
			saveFile = file.substring(file.indexOf("filename=\"") + 10);
			saveFile = saveFile.substring(0, saveFile.indexOf("\n"));
			saveFile = saveFile.substring(saveFile.lastIndexOf("\\") + 1, saveFile.indexOf("\""));
			int lastIndex = contentType.lastIndexOf("=");
			String boundary = contentType.substring(lastIndex + 1, contentType.length());
			int pos;
			pos = file.indexOf("filename=\"");
			pos = file.indexOf("\n", pos) + 1;
			pos = file.indexOf("\n", pos) + 1;
			pos = file.indexOf("\n", pos) + 1;
			int boundaryLocation = file.indexOf(boundary, pos) - 4;
			int startPos = ((file.substring(0, pos)).getBytes()).length;
			int endPos = ((file.substring(0, boundaryLocation)).getBytes()).length;
			
			Date date = new Date();
			String generatedFileName = date.getTime()+"_"+saveFile;

//			System.out.println("generatedFileName : " + generatedFileName);

			File folder1 = new File(uploadFolder);
			if (!folder1.exists()) {
				folder1.mkdir();
			}
			saveFile = uploadFolder + "/" + generatedFileName;
//			System.out.println("File to save :> " + saveFile);
			File ff = new File(saveFile);
			FileOutputStream fileOut = new FileOutputStream(ff);
			fileOut.write(dataBytes, startPos, (endPos - startPos));
			fileOut.flush();
			fileOut.close();

			out.println(generatedFileName);
		}
	}
	
	public void downloadRequestLetter(HttpServletRequest request, HttpServletResponse response)throws IOException{
		PrintWriter out = response.getWriter();
		resourceBundle = ResourceBundle.getBundle("DBInfo");
		String filepath = resourceBundle.getString("upload-files-folder");
		
		String filename = request.getParameter("requestLetter");
//		 System.out.println("filename :: "+filename);
						
//		 String filepath="D:/SBM70/IN_SR_CR_DOCS/SR/";
		 
		  System.out.println("formNameAtServer path---------------------"+filepath+filename);
		  response.setContentType("APPLICATION/OCTET-STREAM"); 
		  response.setHeader("Content-Disposition","attachment; filename="+filename); 
		  java.io.FileInputStream fileInputStream = new java.io.FileInputStream(filepath + filename);  
		  int i; 
		  while ((i=fileInputStream.read()) != -1) {
		    out.write(i); 
		  } 
		  fileInputStream.close();
	}

}
