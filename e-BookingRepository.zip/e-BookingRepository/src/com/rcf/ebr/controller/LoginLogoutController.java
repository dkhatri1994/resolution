package com.rcf.ebr.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Hashtable;

import javax.naming.Context;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.rcf.ebr.dao.AuthenticationUtils;

/**
 * Servlet implementation class LoginController
 */
@WebServlet("/authorization/*")
public class LoginLogoutController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String uri = request.getRequestURI();
//		System.out.println("URI : "+uri);
		String action = uri.substring(uri.lastIndexOf("/")+1);
//		System.out.println("Action : "+action);
		if(action!=null){
			if(action.equals("login"))
				login(request,response);
			else if(action.equals("logout"))
				logout(request,response);
			else if(action.equals("jLogin"))
				jLogin(request, response);
		}
	}
	
	public void login(HttpServletRequest request, HttpServletResponse response){
		response.setContentType("text/html");
		String userName = request.getParameter("userName");
		String password = request.getParameter("password");
		System.out.println("UserName : "+userName+"\nPassword : "+password);
		try{
			boolean isUserExistInAD = AuthenticationUtils.getInstance().isUserCredentialsValidInAD(userName, password);
			String userRole = AuthenticationUtils.getInstance().getUserInfoForAuthorization(userName.trim());
			if(isUserExistInAD){
				HttpSession session = request.getSession();
				session.setAttribute("loggedInUser", userName.trim());
				session.setAttribute("userRole", userRole.trim());
				if(userRole.equals("HO"))
					response.sendRedirect(request.getContextPath()+"/ho-home");
				else if(userRole.equals("CM"))
					response.sendRedirect(request.getContextPath()+"/cm-home");
				else
					response.sendRedirect(request.getContextPath()+"/login?auth=wr");
			}
			else
				response.sendRedirect(request.getContextPath()+"/login?error=wr");		
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void logout(HttpServletRequest request, HttpServletResponse response) throws IOException{
		HttpSession session = request.getSession();
		session.invalidate();
		response.sendRedirect(request.getContextPath()+"/jLogin");
	}
	
	public void jLogin(HttpServletRequest request, HttpServletResponse response){
		response.setContentType("text/html");
		String userName = request.getParameter("userName");
		String password = request.getParameter("password");
		System.out.println("UserName : "+userName+"\nPassword : "+password);
		try{
			String userRole = AuthenticationUtils.getInstance().getUserInfoForAuthorization(userName.trim());
			if(userName.trim().equals(password.trim())){
				HttpSession session = request.getSession();
				session.setAttribute("loggedInUser", userName.trim());
				session.setAttribute("userRole", userRole.trim());
				if(userRole.equals("HO"))
					response.sendRedirect(request.getContextPath()+"/ho-home");
				else if(userRole.equals("CM"))
					response.sendRedirect(request.getContextPath()+"/cm-home");
				else
					response.sendRedirect(request.getContextPath()+"/jLogin?auth=wr");
			}
			else
				response.sendRedirect(request.getContextPath()+"/jLogin?error=wr");		
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
	

	

}
