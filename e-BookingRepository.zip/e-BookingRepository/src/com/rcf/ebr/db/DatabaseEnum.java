/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.rcf.ebr.db;

public enum DatabaseEnum {
	PROVIDER("db-provider"),
	SERVER("server-name"),
	PORT("port"),
	DBNAME("db-name"),
	USERNAME("username"),
	PASSWORD("password"),
	DRIVER("driver-class"),
	URL("url");
	private String value;
	private DatabaseEnum(String value)
    {
	      this.value = value;
	}

	public String value()
    {
		return value;
	}
}
