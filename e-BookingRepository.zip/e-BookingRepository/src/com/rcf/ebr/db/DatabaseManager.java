

package com.rcf.ebr.db;

/**
 *
 * @author Narayan
 */

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.MessageFormat;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

public class DatabaseManager {
    private static ResourceBundle resourceBundle;
    private static DatabaseManager manager;
    private static Connection connection;

    /**
     * Loads Resource Bundle for masterdb.properties Loads Drivers for database
     * connection
     *
     */
    DatabaseManager() {
        resourceBundle = ResourceBundle.getBundle("DBInfo");

        // Check whether all the keys are defined in properties file or not
        boolean isValidResourceBundle = true;
        for (DatabaseEnum databaseEnum : DatabaseEnum.values()) {
            String key = databaseEnum.value();
            try {
                //debug("value :" + resourceBundle.getString(key));
            } catch (MissingResourceException mre) {
                //debug(key + " Not found in Resource Bundle");
                isValidResourceBundle = false;
            }
        }
        // If any key is not found then exit the program
        if (!isValidResourceBundle) {
            System.exit(-1);
        }

        String driver = resourceBundle.getString(DatabaseEnum.DRIVER.value());
        try {
            Class.forName(driver);
        } catch (ClassNotFoundException e) {
            System.err.println("Add suitable driver to classpath for " + driver);
            e.printStackTrace();
        }

    }

    /**
     * Returns a connection object
     *
     * @return
     */
    public static Connection getConnection() {
        if (manager == null) {
            manager = new DatabaseManager();
        }

        try {

            String username = resourceBundle.getString(DatabaseEnum.USERNAME.value());
            String password = resourceBundle.getString(DatabaseEnum.PASSWORD.value());
           // System.out.println("username "+ username+"password"+password +"URL" +manager.getURL());
            connection = DriverManager.getConnection(manager.getURL(), username, password);
            

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return connection;
    }

    /*
     *  Connection  close and Psmt Connection close
     */
    public static void close(Connection connection, PreparedStatement pstmt) throws SQLException {

    	if (pstmt != null) {
            pstmt.close();
        }
        if (connection != null) {
            connection.close();
        }
        
    }
    
    /**
     * @author Narayan
     * @param con
     * @param psmt
     * @param rs
     * @throws SQLException
     */
    public static void closeAllConnection(Connection con, PreparedStatement psmt, ResultSet rs) throws SQLException
    {
    	if(rs!=null)
    	{
    		rs.close();
    	}
    	if(psmt!=null)
    	{
    		psmt.close();
    	}
    	if(con!=null)
    	{
    		psmt.close();
    	}
    }

    /*
     * Check Database Close Connection
     */
    public static boolean isConnClosed(Connection con) throws Exception {

        if(con.isClosed()) {
            return true;
        } else {
            return false;
        }
    }

    String getURL() {
        String modifiedUrl = null;
        String db = resourceBundle.getString(DatabaseEnum.DBNAME.value());
        String server = resourceBundle.getString(DatabaseEnum.SERVER.value());
        String provider = resourceBundle.getString(DatabaseEnum.PROVIDER.value());
        String url = resourceBundle.getString(DatabaseEnum.URL.value());
        String port = resourceBundle.getString(DatabaseEnum.PORT.value());

        if (provider.equalsIgnoreCase("mysql")) {
            // url=jdbc:mysql://<server>/<database_name>
            modifiedUrl = MessageFormat.format(url, server, db);
        } else if (provider.equalsIgnoreCase("oracle")) {
            // url=jdbc:oracle:thin:@<server>[:<1521>]:<database_name>
            modifiedUrl = MessageFormat.format(url, server, port, db);
        } else {
            modifiedUrl = url;
        }
        // debug(modifiedUrl);
        return modifiedUrl;
    }
    
    public static void closeDBConnection(Connection con)
    {
 	   try
 	   {
 		   if(con!=null)
 		   {
 			   con.close();
 		   }
 		   else
 		   {
 			   throw new RuntimeException("Connection is not initialized");
 		   }
 	   }
 	   catch(Exception e)
 	   {
 		   System.out.println("Exception caught inside closeDBConnection() method is : "+e); 
 	   }
    }

    public static void main(String[] args) {
        Connection con = getConnection();

        try {
             System.out.println("Connection--"+con.getClass().getName());
             con.close();
           } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
}
