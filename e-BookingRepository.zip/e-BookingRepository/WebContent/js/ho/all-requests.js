$(document).ready(function(){
	$("#includeSideBarDiv").load("sidebars/ho-sidebar.jsp");
	getAllRequests();
	console.log("Yes, all-request.js loaded...");
	$('.input-group.date').datepicker({
		format: "dd-mm-yyyy",
//		startDate: '-0d',
		endDate:'+0d',
		minViewMode: 0,
		clearBtn: true,
		todayHighlight: true,
		autoclose: true
	});
});

function getAllRequests(){
	
	var fromDate = $.trim($("#fromDate").val());
	var toDate = $.trim($("#toDate").val());
	var location = $.trim($("#location").val());
	console.log(fromDate+" : "+toDate+" : "+ location);
	$("#allRequestsTbody").empty();
	$("#allRequestsTbody").html("");
	if(fromDate!="" || toDate!="" || location!="Select")
		$('#allRequestsTable').DataTable().destroy();
	$.ajaxSetup({async:false});
	$.post("AppController/getAllRequestDetails",{loggedInUser:loggedInUser,fromDate:fromDate,toDate:toDate,location:location},
		function(response)
		{
			var res = JSON.parse(response);
			var newHtml = "";
			for(var i=0;i<res.length;i++){
				newHtml += "<tr><td>"+(i+1)+"</td>"+
							"<td>"+res[i].TxID+"</td>"+
							"<td>"+res[i].RequestName+"</td>"+
							"<td>"+res[i].ReceiptQuantity+"</td>"+
							"<td>"+res[i].RequestTime+"</td>"+
							"<td>"+res[i].PendingDays+"</td>";
				newHtml += res[i].RequestStatus=="Processed"?"<td style='color:green;'>"+res[i].RequestStatus+"</td>":"<td style='color:red;'>"+res[i].RequestStatus+"</td>";
				newHtml += "</tr>";
			}
			$("#allRequestsTbody").html(newHtml);
			$('#allRequestsTable').DataTable({
				"lengthMenu" : [10,13]
//				"bDestroy" : true
			});
		}	
	);

//	$('#allRequestsTable_length').hide();
	$(".dataTables_filter").find('input').attr("placeholder","Universal Search");	
}

function rendorDataTable(){
	
}

