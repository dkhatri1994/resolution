$(document).ready(function(){
	$("#includeSideBarDiv").load("sidebars/ho-sidebar.jsp");
	getAllReceiptBooks();
});

function getAllReceiptBooks(){
	var workstep = "HO";
	$.ajaxSetup({async:false});
	$.post("AppController/getAllReceiptBooks",{loggedInUser:loggedInUser,workstep:workstep},
		function(response)
		{
			var res = JSON.parse(response);
			console.log(response);
			var newHtml = "";
			for(var i=0;i<res.length;i++){
				newHtml += "<tr>"+
							"<td>"+(i+1)+"</td>"+
							"<td>"+res[i].TXID+"</td>"+
							"<td><!--<a data-toggle='modal' data-target='leafDetailsModal' onclick='showReceiptLeafs(this)'>-->"+res[i].RECEIPT_BOOK_NUMBER+"<!--</a>--></td>"+
							"<td>"+res[i].SEQUENCE_START_NUMBER+"</td>"+
							"<td>"+res[i].SEQUENCE_END_NUMBER+"</td></tr>";
			}
			$("#receiptBookDetailsTbody").html(newHtml);
		}	
	);
	$('#receiptBookDetailsTable').DataTable({
		"lengthMenu" : [10,15]
	});
//	$('#raisedRequestsTable_length').hide();
	$(".dataTables_filter").find('input').attr("placeholder","Universal Search");
	
	setActivedTab("Received Request Books");
	
}