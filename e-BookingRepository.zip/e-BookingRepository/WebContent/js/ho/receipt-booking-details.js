$(document).ready(function(){
	$("#includeSideBarDiv").load("sidebars/ho-sidebar.jsp");
	$("#receiptDetailsTableContainerDiv").hide();
	$("#courierDetailsDiv").hide();
	$("#submissionDIV").hide();
	getRequesterDetails();
	$('.input-group.date').datepicker({
		format: "dd-mm-yyyy",
		startDate: '-0d',
		minViewMode: 0,
		clearBtn: true,
		todayHighlight: true,
		autoclose: true
	});
	showComments();
	$("#comment").hide();
	$("#postCommentBtn").hide();
	
});

function hideShowDiv(){
	$("#receiptDetailsTableContainerDiv").slideToggle();
	var idObj = jQuery("#iDownGlyphicon").attr("class");
	if(idObj=="glyphicon glyphicon-chevron-down")
	{
		jQuery("#iDownGlyphicon").attr("class","glyphicon glyphicon-chevron-up");
	}
	else
	{
		jQuery("#iDownGlyphicon").attr("class","glyphicon glyphicon-chevron-down");
	}
	
//	$("i").toggleClass("glyphicon glyphicon-chevron-up");
}

function getRequesterDetails(){
	$.post("AppController/getRequesterDetails",{txId:txId},
		function(response)
		{
			var res = JSON.parse(response);
//			console.log(res[0].RequesterNameWithSapid);
			$("#requesterNameWithSapid").val(res[0].RequesterNameWithSapid);
			$("#location").val(res[0].RequestLocation);
			$("#requestedOn").val(res[0].RequestTime);
			$("#receiptQuantity").val(res[0].ReceiptQuantity);
//			$("#requestLetter").text(res[0].RequestLetter);
//			console.log("res[0].RequestLetter : "+res[0].RequestLetter);
			if($.trim(res[0].RequestLetter)!="NA")
				$("#requestLetter").attr("href","FileManagementController/downloadRequestLetter?requestLetter="+res[0].RequestLetter);
			else{
				console.log("Not uploaded");
				$("#requestLetter").click(function(){
					swal({
						  title: "Alert !",
						  text: "Request letter not uploaded by CM !",
						  type: "warning",
						  confirmButtonText: "Okay"
						});
				});
			}
		}
	);
}

function fillReceiptBookDetails(){
	var availableReceipts = $.trim($("#availableReceipts").val());
	var receiptQuantity = $.trim($("#receiptQuantity").val());
	if(availableReceipts=="" || availableReceipts==0){
		swal({
			  title: "Alert !",
			  text: "Please enter number of available receipt book (greater or equals to One)",
			  type: "error",
			  confirmButtonText: "Okay"
			});
		return false;
	}
	else if(receiptQuantity<availableReceipts){
		swal({
			  title: "Warning !",
			  text: "You have entered more than requested receipt books !",
			  type: "warning",
			  confirmButtonText: "Okay"
			});
		return false;
	}
	else{
		$("#availableReceiptDiv").hide(1000);
		$("#receiptDetailsTableContainerDiv").show();
		$("#courierDetailsDiv").show(2000);
		$("#submissionDIV").show(3000);
		createReceiptBookEntryTable(availableReceipts);
	}
	
}

function createReceiptBookEntryTable(availableReceipts){
	console.log("availableReceipts : "+availableReceipts);
	var newHtml = "";
	for(var i=0;i<availableReceipts;i++){
		newHtml += "<tr><td>"+(i+1)+"</td><td><input type='text' class='form-control receiptBookCls' placeholder='Enter Receipt Book Number...'"+ 
					" name='receiptBookNumber_"+(i+1)+"' id='receiptBookNumber_"+(i+1)+"'></td>"+
					"<td><input disabled='disabled' type='text' class='form-control startSeqCls' placeholder='Enter Sequence Start Number...' "+
					"name='sequenceStartNumber_"+(i+1)+"' id='sequenceStartNumber_"+(i+1)+"'></td>"+
					"<td><input disabled='disabled' type='text' class='form-control endSeqCls' placeholder='Enter Sequence End Number...' "+
					"name='sequenceEndNumber_"+(i+1)+"' id='sequenceEndNumber_"+(i+1)+"'></td></tr>";
	}
	$("#receiptBookDetailTbody").html(newHtml);
	setPredictiveSearch();
}

function validateFields(){
	var availableReceipts = $.trim($("#availableReceipts").val());
	var courierAgencyName = $.trim($("#courierAgencyName").val());
	var courierContactNumber = $.trim($("#courierContactNumber").val());
	var courierDispatchDate = $.trim($("#courierDispatchDate").val());
	var expectedDeliveryDate = $.trim($("#expectedDeliveryDate").val());
	var courierAddress = $.trim($("#courierAddress").val());
//	console.log(courierAgencyName+" : "+courierContactNumber+" : "+courierDispatchDate+" : "+expectedDeliveryDate+" : "+courierAddress);
	if(courierContactNumber==""){
		courierContactNumber = "NA";
	}
	for(var i=0;i<availableReceipts;i++){
		var receiptBookNumber = $.trim($("#receiptBookNumber_"+(i+1)).val());
		var sequenceStartNumber = $.trim($("#sequenceStartNumber_"+(i+1)).val());
		var sequenceEndNumber = $.trim($("#sequenceEndNumber_"+(i+1)).val());
		if(receiptBookNumber==""){
			swal({
				  title: "Alert !",
				  text: "Please enter receipt book number",
				  type: "error",
				  confirmButtonText: "Okay"
				});
			return false;
		}
		else if(sequenceStartNumber==""){
			swal({
				  title: "Alert !",
				  text: "Please enter sequence start number",
				  type: "error",
				  confirmButtonText: "Okay"
				});
			return false;
		}
		else if(sequenceEndNumber==""){
			swal({
				  title: "Alert !",
				  text: "Please enter sequence end number",
				  type: "error",
				  confirmButtonText: "Okay"
				});
			return false;
		}
	}
	if(courierAgencyName==""){
		swal({
			  title: "Alert !",
			  text: "Please enter courier agency name",
			  type: "error",
			  confirmButtonText: "Okay"
			});
		return false;
	}
	/*else if(courierContactNumber=="" || isNaN(courierContactNumber)){
		swal({
			  title: "Alert !",
			  text: "Please enter a valid courier contact number",
			  type: "error",
			  confirmButtonText: "Okay"
			});
		return false;
		courierContactNumber = "NA";
	}*/
	else if(courierDispatchDate==""){
		swal({
			  title: "Alert !",
			  text: "Please select courier dispatch date",
			  type: "error",
			  confirmButtonText: "Okay"
			});
		return false;
	}
	else if(expectedDeliveryDate==""){
		swal({
			  title: "Alert !",
			  text: "Please select expected delivery date",
			  type: "error",
			  confirmButtonText: "Okay"
			});
		return false;
	}
	else if(courierAddress==""){
		swal({
			  title: "Alert !",
			  text: "Please enter corresponding address",
			  type: "error",
			  confirmButtonText: "Okay"
			});
		return false;
	}
	else
		return true;
}

function saveReceiptAndCourierDetails(){
	var receiptQuantity = $.trim($("#receiptQuantity").val());
	var availableReceipts = $.trim($("#availableReceipts").val());
	var courierAgencyName = $.trim($("#courierAgencyName").val());
	var courierContactNumber = $.trim($("#courierContactNumber").val());
	var courierDispatchDate = $.trim($("#courierDispatchDate").val());
	var expectedDeliveryDate = $.trim($("#expectedDeliveryDate").val());
	var courierAddress = $.trim($("#courierAddress").val());
	var receiptsForAdjustment = receiptQuantity - availableReceipts;
	var receiptBookIssueTime = get_Formated_Date();
	console.log("loggedInUser : "+loggedInUser);
//	var rows = $("#receiptBookDetailTbody > tr").length;
	var isFormValidated = validateFields();
	  var receiptBookData = "";
	if(isFormValidated){
		console.log("validated : "+isFormValidated);
		for(var i=0;i<availableReceipts;i++){
			receiptBookData += $.trim($("#receiptBookNumber_"+(i+1)).val())+"##"+$.trim($("#sequenceStartNumber_"+(i+1)).val())+
								"##"+$.trim($("#sequenceEndNumber_"+(i+1)).val())+"<END>";
		}
		
		$.post("AppController/saveReceiptAndCourierDetails",{availableReceipts:availableReceipts,courierAgencyName:courierAgencyName,
			courierContactNumber:courierContactNumber,courierDispatchDate:courierDispatchDate,expectedDeliveryDate:expectedDeliveryDate,
			courierAddress:courierAddress,receiptsForAdjustment:receiptsForAdjustment,receiptBookData:receiptBookData,txId:txId,
			receiptBookIssueTime:receiptBookIssueTime,loggedInUser:loggedInUser},
			function(response){
				console.log(response);
				
				if($.trim(response)=="saved"){
					swal({
						  title: "Alert !",
						  text: "Receipt & courier details are saved",
						  type: "success",
						  confirmButtonText: "Cool"
						},function(){
							window.location.href = "receipt-book-requests";
						});
				}
				else{
					swal({
						  title: "Alert !",
						  text: "Error occurred while data saving...",
						  type: "error",
						  confirmButtonText: "Oh No !!!"
						},function(){
//							window.location.href = "receipt-book-requests";
						});
				}
			}
		);
	}	
}

function get_Formated_Date()
{
  var date=new Date();
  var month=["January","February","March","April","May","June","July","August","September","October","November","December"];
  var hours=date.getHours();
  var minutes=date.getMinutes();
  var ampm=hours>=12? "PM":"AM";
  hours = hours % 12;
  hours = hours ? hours : 12;
  minutes = minutes < 10 ? '0'+minutes : minutes;
  var date1=month[date.getMonth()]+" "+date.getDate()+", "+date.getFullYear()+" "+hours+":"+minutes+" "+ampm;
  return date1;
}
function showCommentModal(){
	$("#commentBoxModal").modal('show');
}
function toggleCommentArea()
{
	$("#comment").toggle();
	$("#postCommentBtn").toggle();
	$("#comment").focus();
}
function addComment()
{
	//console.log(loggedInUser+" : "+userName+" : "+pid);
	var commentOn = get_Formated_Date();
	var comment = $.trim($("#comment").val());
	//console.log("date & cmt : "+date+" : "+comment);
	$.ajaxSetup({async: false});
	$.post("AppController/addComment",{loggedInUser:loggedInUser,userName:userName,txId:txId,commentOn:commentOn,comment:comment},
			function(response)
			{
				//console.log("addComment response : "+response);
				if(response!=0)
				{
//					alert("Comment has been posted.");
					swal({
						  title: "Alert!",
						  text: "Comment has been posted.",
						  type: "success",
						  confirmButtonText: "Cool"
						});
					showComments();
					$("#comment").hide();
					$("#postCommentBtn").hide();
				}
			}
			
	);
}
function showComments()
{
	$.ajaxSetup({async: false});
	$.post("AppController/showComments",{txId:txId},
			function(response)
			{
				//console.log(response);
				var res = JSON.parse(response);
				var newHtml = "";
				//console.log(res.length);
				if(res.length!=0)
				{
					for(var i=0;i<res.length;i++)
					{
						newHtml += "<tr><td>"+res[i].commentedOn+"</td><td>"+res[i].comment+"</td><td>"+res[i].commentedBy+"</td></tr>";
					}
					$("#commentTableTbody").html(newHtml);
				}
				else
				{
					$("#commentTableTbody").append("<tr><td></td><td ><font color='red'>No any comment has been posted yet</font></td><td></td></tr>");
					$("tr:odd").css("background-color","#e1e2e3");
				}
				
			}
	);
}

function setPredictiveSearch(){
	$.ajaxSetup({async: false});
	$.post('AppController/getReceiptBookMaster',{},
			function(response)
			{
				var jsonArr = JSON.parse(response);
				var receiptBookArr = [], startSeqArr = [], endSeqArr = [];
				for(var i=0;i<jsonArr.length;i++){
					receiptBookArr.push(jsonArr[i].RECEIPT_BOOK_NUMBER);
					startSeqArr.push(jsonArr[i].START_SEQUENCE_NUMBER);
					endSeqArr.push(jsonArr[i].END_SEQUENCE_NUMBER);
				}
				/*console.log(receiptBookArr);
				console.log(startSeqArr);
				console.log(endSeqArr);*/
				
				// Constructing the suggestion engine
				var receiptBookNumbers = new Bloodhound({
					datumTokenizer: Bloodhound.tokenizers.whitespace,
					queryTokenizer: Bloodhound.tokenizers.whitespace,
					local: receiptBookArr
				});
				/*var startSequences = new Bloodhound({
					datumTokenizer: Bloodhound.tokenizers.whitespace,
					queryTokenizer: Bloodhound.tokenizers.whitespace,
					local: startSeqArr
				});
				var endSequences = new Bloodhound({
					datumTokenizer: Bloodhound.tokenizers.whitespace,
					queryTokenizer: Bloodhound.tokenizers.whitespace,
					local: endSeqArr
				});*/
				
				// Initializing the typeahead
				$('.receiptBookCls').typeahead({
					hint: true,
					highlight: true,  //Enable substring highlighting 
					minLength: 1  //Specify minimum characters required for showing result 
				},
				{
					name: 'receiptBookNumbers',
					source: receiptBookNumbers
				});
				
				/*$('.startSeqCls').typeahead({
					hint: true,
					highlight: true,  //Enable substring highlighting 
					minLength: 1  //Specify minimum characters required for showing result 
				},
				{
					name: 'startSequences',
					source: startSequences
				});
				
				$('.endSeqCls').typeahead({
					hint: true,
					highlight: true,  //Enable substring highlighting 
					minLength: 1  //Specify minimum characters required for showing result 
				},
				{
					name: 'endSequences',
					source: endSequences
				});*/
			}
	);
	
	
	$('.receiptBookCls').bind('typeahead:select', function(ev, suggestion) {
		  var id = $(this).attr('id');
		  setStartEndSequences(id,suggestion);
		});
}

function setStartEndSequences(id,receiptBookNumber){
//	console.log("setStartEndSequences calling..."+suggestion+" : "+id);
//	console.log($("#"+id).closest("tr").find("td:eq(2)").text("wdew"));
//	$("#"+id).closest("tr").find("td:eq(2)").find("input").val("inp-2");
//	$("#"+id).closest("tr").find("td:eq(3)").find("input").val("inp-3");
	$.ajaxSetup({async: false});
	$.post('AppController/getStartEndSequencesByReceiptBookNumber',{receiptBookNumber:receiptBookNumber},
		function(response)
		{
			var res = JSON.parse(response);
			$("#"+id).closest("tr").find("td:eq(2)").find("input").val(res[0].START_SEQUENCE_NUMBER);
			$("#"+id).closest("tr").find("td:eq(3)").find("input").val(res[0].END_SEQUENCE_NUMBER);
		}
	);
	
}