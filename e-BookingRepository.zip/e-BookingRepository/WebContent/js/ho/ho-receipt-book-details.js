$(document).ready(function(){
	$("#includeSideBarDiv").load("sidebars/ho-sidebar.jsp");
	getReceiptBookAndCourierDetails();
	console.log("hideBtn : "+hideBtn);
	if(hideBtn=="true"){
		$("#confirmationDIV").hide();
	}
	
	$('.input-group.date').datepicker({
		format: "dd-mm-yyyy",
		startDate: '-0d',
		minViewMode: 0,
		clearBtn: true,
		todayHighlight: true,
		autoclose: true
	});
	
	/*if($("#checkCourierAgencyDetails").is(":checked")){
		var courierAgencyName = $.trim($("#courierAgencyName").val());
		console.log(courierAgencyName);
		$("#recCourierAgencyName").val(courierAgencyName);
	}*/
	$("#checkCourierAgencyDetails").change(function(){
		if(this.checked){
			var courierAgencyName = $.trim($("#courierAgencyName").val());
			var courierContactNumber = $.trim($("#courierContactNumber").val());
			var expectedDeliveryDate = $.trim($("#expectedDeliveryDate").val());
			$("#recCourierAgencyName").val(courierAgencyName);
			$("#recCourierContactNumber").val(courierContactNumber);
			$("#recCourierReceiveDate").val(expectedDeliveryDate);
		}
		else{
			$("#recCourierAgencyName").val("");
			$("#recCourierContactNumber").val("");
			$("#recCourierReceiveDate").val("");
		}
		
	});
});

function getReceiptBookAndCourierDetails(){
	$.post("AppController/getReceiptBookAndCourierDetails",{txId:txId},
		function(response){
			var jsonObj = jQuery.parseJSON(response);
//			console.log("adj : "+jsonObj.courierData[0].RECEIPTS_FOR_ADJUSTMENT);
			$("#requestBookIssuedBy").val(jsonObj.courierData[0].RECEIPT_BOOK_ISSUED_BY);
			$("#receiptBookRequested").val(jsonObj.courierData[0].RECEIPTS_FOR_ADJUSTMENT+jsonObj.courierData[0].AVAILABLE_RECEIPT_QUANTITY);
			$("#availableReceipts").val(jsonObj.courierData[0].AVAILABLE_RECEIPT_QUANTITY);
			$("#receiptBookIssueTime").val(jsonObj.courierData[0].RECEIPT_BOOK_ISSUE_TIME);
			$("#courierAgencyName").val(jsonObj.courierData[0].COURIER_AGENCY);
			$("#courierContactNumber").val(jsonObj.courierData[0].COURIER_CONTACT_NUMBER);
			$("#courierDispatchDate").val(jsonObj.courierData[0].COURIER_SENDING_DATE);
			$("#expectedDeliveryDate").val(jsonObj.courierData[0].COURIER_EXP_DELIVERY_DATE);
			$("#courierAddress").val(jsonObj.courierData[0].ADDRESS);
			
//			console.log(jsonObj.courierData[0].REC_COURIER_AGENCY);
			if(hideBtn=="true"){
//				console.log("hide btn true");
				$("#recCourierAgencyName").attr("disabled","disabled");
				$("#recCourierContactNumber").attr("disabled","disabled");
				$("#checkCourierAgencyDetailsSpan").hide();
//				$(".input-group-addon").hide();
				$("#recCourierAgencyName").val(jsonObj.courierData[0].REC_COURIER_AGENCY);
				$("#recCourierContactNumber").val(jsonObj.courierData[0].REC_COURIER_CONTACT);
				$("#recCourierReceiveDate").val(jsonObj.courierData[0].REC_COURIER_DATE);
			}
			
			var newHtml = "";
			for(var i=0;i<jsonObj.receiptData.length;i++){
				newHtml += "<tr><td>"+(i+1)+"</td>"+
						   " <td>"+jsonObj.receiptData[i].RECEIPT_BOOK_NUMBER+"</td>"+
						   " <td>"+jsonObj.receiptData[i].SEQUENCE_START_NUMBER+"</td>"+
						   "<td>"+jsonObj.receiptData[i].SEQUENCE_END_NUMBER+"</td></tr>";
			}
			$("#receiptBookDetailTbody").html(newHtml);
	});
}
