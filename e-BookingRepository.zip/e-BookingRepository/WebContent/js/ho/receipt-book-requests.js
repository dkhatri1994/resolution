$(document).ready(function(){
	$("#includeSideBarDiv").load("sidebars/ho-sidebar.jsp");
	getReceiptBookRequests();
});

function getReceiptBookRequests(){
	var workStep = "HO";
	type="availableRequest";
	$.ajaxSetup({async:false});
	$.post("AppController/getReceiptBookRequests",{workStep:workStep,type:type,loggedInUser:requestedBy},
		function(response)
		{
			var res = JSON.parse(response);
			var newHtml = "";
			console.log(res[1].TxID);
			for(var i=0;i<res.length;i++){
				newHtml += "<tr><td>"+(i+1)+"</td>"+
							"<td><a style='cursor:pointer;' href='receipt-booking-details?TxID="+res[i].TxID+"'>"+res[i].TxID+"</a></td>"+
							"<td>"+res[i].RequestName+"</td>"+
							"<td>"+res[i].ReceiptQuantity+"</td>"+
							"<td>"+res[i].RequestedBy+"</td>"+
							"<td>"+res[i].RequestTime+"</td>"+
							"<td>"+res[i].pendingDays+"</td></tr>";
			}
			$("#availableRequestsTbody").html(newHtml);
		}
	);
	$('#availableRequestsTable').DataTable({
		"lengthMenu" : [10,15]
	});
	$(".dataTables_filter").find('input').attr("placeholder","Universal Search");
	
	setActivedTab("Receipt Book Requests");
	
}