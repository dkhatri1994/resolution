$(document).ready(function(){
	$("#includeSideBarDiv").load("sidebars/ho-sidebar.jsp");
	getCmConfirmedRequests();
});

function getCmConfirmedRequests(){
	var workStep = "HO";
	var type = "cmConfirmedRequests";
	$.ajaxSetup({async:false});
	$.post("AppController/getReceiptBookRequests",{workStep:workStep,type:type,loggedInUser:requestedBy},
		function(response)
		{
			var res = JSON.parse(response);
			var newHtml = "";
//			console.log(res[1].TxID);
			for(var i=0;i<res.length;i++){
				newHtml += "<tr><td>"+(i+1)+"</td>"+
							"<td><a style='cursor:pointer;' href='ho-receipt-book-details?TxID="+res[i].TxID+"&hideBtn=true'>"+res[i].TxID+"</a></td>"+
							"<td>"+res[i].RequestName+"</td>"+
							"<td>"+res[i].RequestTime+"</td></tr>";
			}
			$("#confirmedRequestsTbody").html(newHtml);
		}	
	);
	$('#confirmedRequestsTable').DataTable({
		"lengthMenu" : [10,15]
	});
	$(".dataTables_filter").find('input').attr("placeholder","Universal Search");
	
	setActivedTab("CM Confirmed Requests");
	
}