$(document).ready(function(){
	
	$("#includeSideBarDiv").load("sidebars/ho-sidebar.jsp");
	
});