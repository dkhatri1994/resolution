$(document).ready(function(){
	$("#includeSideBarDiv").load("sidebars/ho-sidebar.jsp");
	$("#addReceiptModal").modal('show');
});

function addReceiptBook(){
	var receiptNumber = $.trim($("#receiptNumber").val());
	var startSequenceNumber = $.trim($("#startSequenceNumber").val());
	var endSequenceNumber = $.trim($("#endSequenceNumber").val());
//	console.log(receiptNumber+" : "+startSequenceNumber+" : "+endSequenceNumber);
	if(isValidated(receiptNumber,startSequenceNumber,endSequenceNumber)){
		$.post("AppController/addNewReceiptBook",{receiptNumber:receiptNumber,startSequenceNumber:startSequenceNumber,
			endSequenceNumber:endSequenceNumber},
			function(response)
			{
				if($.trim(response)==1){
					swal({
						title : "Alert !",
						type : "success",
						text : "Receipt Book successfully added.",
						confirmButtonText : "Cool !"
					},function(){
						window.location.href="ho-home";
					});
				}
				else if($.trim(response)==2){
					swal({
						title : "Alert !",
						type : "error",
						text : "There is duplicacy found in receipt book or start sequence number or end sequence number",
						confirmButtonText : "Cool !"
					});
				}
			}
		);
	}	
}

function isValidated(receiptNumber,startSequenceNumber,endSequenceNumber){
//	console.log(receiptNumber+" : "+startSequenceNumber+" : "+endSequenceNumber);
	if(receiptNumber==""){
		swal({
			title : "Alert !",
			text : "Please enter receipt book number",
			type : "error",
			confirmButtonText : "Okay"
		});
		return false;
	}
	else if(startSequenceNumber==""){
		swal({
			title : "Alert !",
			text : "Please enter start sequence number",
			type : "error",
			confirmButtonText : "Okay"
		});
		return false;
	}
	else if(endSequenceNumber==""){
		swal({
			title : "Alert !",
			text : "Please enter end sequence number",
			type : "error",
			confirmButtonText : "Okay"
		});
		return false;
	}
	else
		return true;
}