$(document).ready(function(){
	$("#includeSideBarDiv").load("sidebars/cm-sidebar.jsp");
	getReceiptBookAndCourierDetails();
	console.log("hideBtn : "+hideBtn);
	if(hideBtn=="true"){
		$("#confirmationDIV").hide();
	}
	
	$('.input-group.date').datepicker({
		format: "dd-mm-yyyy",
		startDate: '-0d',
		minViewMode: 0,
		clearBtn: true,
		todayHighlight: true,
		autoclose: true
	});
	
	/*if($("#checkCourierAgencyDetails").is(":checked")){
		var courierAgencyName = $.trim($("#courierAgencyName").val());
		console.log(courierAgencyName);
		$("#recCourierAgencyName").val(courierAgencyName);
	}*/
	$("#checkCourierAgencyDetails").change(function(){
		if(this.checked){
			var courierAgencyName = $.trim($("#courierAgencyName").val());
			var courierContactNumber = $.trim($("#courierContactNumber").val());
			var expectedDeliveryDate = $.trim($("#expectedDeliveryDate").val());
			$("#recCourierAgencyName").val(courierAgencyName);
			$("#recCourierContactNumber").val(courierContactNumber);
			$("#recCourierReceiveDate").val(expectedDeliveryDate);
		}
		else{
			$("#recCourierAgencyName").val("");
			$("#recCourierContactNumber").val("");
			$("#recCourierReceiveDate").val("");
		}
		
	});
	showComments();
	$("#comment").hide();
	$("#postCommentBtn").hide();
});

function getReceiptBookAndCourierDetails(){
	$.post("AppController/getReceiptBookAndCourierDetails",{txId:txId},
		function(response){
			var jsonObj = jQuery.parseJSON(response);
//			console.log("adj : "+jsonObj.courierData[0].RECEIPTS_FOR_ADJUSTMENT);
			$("#requestBookIssuedBy").val(jsonObj.courierData[0].RECEIPT_BOOK_ISSUED_BY);
			$("#receiptBookRequested").val(jsonObj.courierData[0].RECEIPTS_FOR_ADJUSTMENT+jsonObj.courierData[0].AVAILABLE_RECEIPT_QUANTITY);
			$("#availableReceipts").val(jsonObj.courierData[0].AVAILABLE_RECEIPT_QUANTITY);
			$("#receiptBookIssueTime").val(jsonObj.courierData[0].RECEIPT_BOOK_ISSUE_TIME);
			$("#courierAgencyName").val(jsonObj.courierData[0].COURIER_AGENCY);
			$("#courierContactNumber").val(jsonObj.courierData[0].COURIER_CONTACT_NUMBER);
			$("#courierDispatchDate").val(jsonObj.courierData[0].COURIER_SENDING_DATE);
			$("#expectedDeliveryDate").val(jsonObj.courierData[0].COURIER_EXP_DELIVERY_DATE);
			$("#courierAddress").val(jsonObj.courierData[0].ADDRESS);
			
//			console.log(jsonObj.courierData[0].REC_COURIER_AGENCY);
			if(hideBtn=="true"){
//				console.log("hide btn true");
				$("#recCourierAgencyName").attr("disabled","disabled");
				$("#recCourierContactNumber").attr("disabled","disabled");
				$("#checkCourierAgencyDetailsSpan").hide();
//				$(".input-group-addon").hide();
				$("#recCourierAgencyName").val(jsonObj.courierData[0].REC_COURIER_AGENCY);
				$("#recCourierContactNumber").val(jsonObj.courierData[0].REC_COURIER_CONTACT);
				$("#recCourierReceiveDate").val(jsonObj.courierData[0].REC_COURIER_DATE);
			}
			
			var newHtml = "";
			for(var i=0;i<jsonObj.receiptData.length;i++){
				newHtml += "<tr><td>"+(i+1)+"</td>"+
						   " <td>"+jsonObj.receiptData[i].RECEIPT_BOOK_NUMBER+"</td>"+
						   " <td>"+jsonObj.receiptData[i].SEQUENCE_START_NUMBER+"</td>"+
						   "<td>"+jsonObj.receiptData[i].SEQUENCE_END_NUMBER+"</td></tr>";
			}
			$("#receiptBookDetailTbody").html(newHtml);
	});
}

function confirmReceiptAndCourierDetails(){
	var recCourierAgencyName = $.trim($("#recCourierAgencyName").val());
	var recCourierContactNumber = $.trim($("#recCourierContactNumber").val());
	var recCourierReceiveDate = $.trim($("#recCourierReceiveDate").val());
	
	if(recCourierAgencyName=="" || recCourierContactNumber=="" || recCourierReceiveDate==""){
		swal({
			title : "Alert !",
			text : "Please enter received courier agency details",
			type : "error",
			confirmButtonText : "Okay"
		});
		
		return false;
	}
	
	$.post("AppController/confirmReceiptAndCourierDetails",{txId:txId,recCourierAgencyName:recCourierAgencyName,
		recCourierContactNumber:recCourierContactNumber,recCourierReceiveDate:recCourierReceiveDate},
		function(response){
//			console.log(response);
			if(response==1){
				swal({
					title : "Alert !",
					text : "Receipt and Courier details confirmed",
					type : "success",
					confirmButtonText : "Okay"
				},function(){
					window.location.href = "processed-requests";
				});
			}
		}
	);
}
function showCommentModal(){
	$("#commentBoxModal").modal('show');
}
function toggleCommentArea()
{
	$("#comment").toggle();
	$("#postCommentBtn").toggle();
	$("#comment").focus();
}
function addComment()
{
	//console.log(loggedInUser+" : "+userName+" : "+pid);
	var commentOn = get_Formated_Date();
	var comment = $.trim($("#comment").val());
	//console.log("date & cmt : "+date+" : "+comment);
	$.ajaxSetup({async: false});
	$.post("AppController/addComment",{loggedInUser:requestedBy,userName:userName,txId:txId,commentOn:commentOn,comment:comment},
			function(response)
			{
				//console.log("addComment response : "+response);
				if(response!=0)
				{
//					alert("Comment has been posted.");
					swal({
						  title: "Alert!",
						  text: "Comment has been posted.",
						  type: "success",
						  confirmButtonText: "Cool"
						});
					showComments();
					$("#comment").hide();
					$("#postCommentBtn").hide();
				}
			}
			
	);
}
function showComments()
{
	$.ajaxSetup({async: false});
	$.post("AppController/showComments",{txId:txId},
			function(response)
			{
				//console.log(response);
				var res = JSON.parse(response);
				var newHtml = "";
				//console.log(res.length);
				if(res.length!=0)
				{
					for(var i=0;i<res.length;i++)
					{
						newHtml += "<tr><td>"+res[i].commentedOn+"</td><td>"+res[i].comment+"</td><td>"+res[i].commentedBy+"</td></tr>";
					}
					$("#commentTableTbody").html(newHtml);
				}
				else
				{
					$("#commentTableTbody").append("<tr><td></td><td ><font color='red'>No any comment has been posted yet</font></td><td></td></tr>");
					$("tr:odd").css("background-color","#e1e2e3");
				}
				
			}
	);
}
function get_Formated_Date()
{
  var date=new Date();
  var month=["January","February","March","April","May","June","July","August","September","October","November","December"];
  var hours=date.getHours();
  var minutes=date.getMinutes();
  var ampm=hours>=12? "PM":"AM";
  hours = hours % 12;
  hours = hours ? hours : 12;
  minutes = minutes < 10 ? '0'+minutes : minutes;
  var date1=month[date.getMonth()]+" "+date.getDate()+", "+date.getFullYear()+" "+hours+":"+minutes+" "+ampm;
  return date1;
}