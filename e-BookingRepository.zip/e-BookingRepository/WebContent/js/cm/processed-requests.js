$(document).ready(function(){
	$("#includeSideBarDiv").load("sidebars/cm-sidebar.jsp");
	getProcessedRequests();
});

function getProcessedRequests(){
	var workStep = "CM";
	var type = "processedRequests";
	$.ajaxSetup({async:false});
	$.post("AppController/getReceiptBookRequests",{workStep:workStep,type:type,loggedInUser:requestedBy},
		function(response)
		{
			var res = JSON.parse(response);
			var newHtml = "";
//			console.log(res[1].TxID);
			for(var i=0;i<res.length;i++){
				newHtml += "<tr><td>"+(i+1)+"</td>"+
							"<td><a style='cursor:pointer;' href='receipt-book-details?TxID="+res[i].TxID+"'>"+res[i].TxID+"</a></td>"+
							"<td>"+res[i].RequestName+"</td>"+
							"<td>"+res[i].RequestTime+"</td></tr>";
			}
			$("#processedRequestsTbody").html(newHtml);
		}	
	);
	$('#processedRequestsTable').DataTable({
		"lengthMenu" : [10,15]
	});
	$(".dataTables_filter").find('input').attr("placeholder","Universal Search");
	
	setActivedTab("HO Processed Requests");
}