$(document).ready(function(){
	$("#includeSideBarDiv").load("sidebars/cm-sidebar.jsp");// WEB-INF/views/cm/
//	setInterval(setActivedTab("Request Receipt Book"),5000);
	setTotalReceiptRequestCounts();
	setProcessedReceiptsCount();
	setReceiptSentToHOCount();
	setPendingReceiptRequest();
	$("#requestLetter").attr("disabled","disabled");
});

function bookReceipts(fileName){
	var receiptQuantity = $.trim($("#receiptQuantity").val());
	var requestLetter = $.trim($("#requestLetter").val());
	var requestName = "";
	if($.trim($("#requestName").val())=="Agency")
		requestName = $.trim($("#agencyName").val());
	else
		requestName = $.trim($("#requestName").val())
	
	var location = $.trim($("#location").val());
	console.log("location: "+location);
	requestLetter = requestLetter.replace("C:\\fakepath\\","");
	var requestTime = get_Formated_Date();
	var workStep = "CM";
	var nextWorkStep = "HO";
	
	console.log("fileName : "+fileName);
	
//	console.log(receiptQuantity+" : "+requestLetter+" : "+requestTime+" : "+requestedBy);
	
	if(receiptQuantity==""){
		swal({
			  title: "Alert!",
			  text: "Please enter receipt book quantity",
			  type: "error",
			  animation:true,
			  confirmButtonText: "Cool"
			});
		return false;
	}
	/*var resp = uploadRequestLetter('requestLetter');
	console.log("response from file upload : > "+resp);*/
	$.ajaxSetup({async:false});
	$.post("AppController/requestReceiptBook",{receiptQuantity:receiptQuantity,requestLetter:fileName,requestName:requestName,
		requestTime:requestTime,requestedBy:requestedBy,workStep:workStep,nextWorkStep:nextWorkStep,location:location},
		function(response){
			if(response==1){
				swal({
					  title: "Alert!",
					  text: "Receipt booking request has been created",
					  type: "success",
					  confirmButtonText: "Cool"
					},function(){
						window.location.href="cm-home";
					});
				
			}
			else{
				console.log("Receipt not booked, data not saving.. : "+response);
			}
			
		}
	);
}

function saveDateAnduploadRequestLetter(id){
	var requestLetter = $.trim($("#"+id).val());
	console.log("requestLetter : "+requestLetter);
	if(requestLetter == "")
	{
		/*swal({
			  title: "Alert!",
			  text: "Request letter not uploaded !",
			  type: "warning",
			  confirmButtonText: "Not an issue !!!"
			},function(){*/
				bookReceipts("NA");
//			});
		
	}
	else             
	{
	$.ajaxFileUpload({
            url : 'FileManagementController/uploadRequestLetter',
            secureuri:false,
            fileElementId:id,
            data : ({
		    file:requestLetter
            }),
             success: function (response){
            	 console.log("saved File > "+response);
            	 bookReceipts($.trim(response));
			  },
            error : function()
             {
                alert("Sorry, The requested property could not be found.");
            }             
        });
 }
}

function get_Formated_Date()
{
  var date=new Date();
  var month=["January","February","March","April","May","June","July","August","September","October","November","December"];
  var hours=date.getHours();
  var minutes=date.getMinutes();
  var ampm=hours>=12? "PM":"AM";
  hours = hours % 12;
  hours = hours ? hours : 12;
  minutes = minutes < 10 ? '0'+minutes : minutes;
  var date1=month[date.getMonth()]+" "+date.getDate()+", "+date.getFullYear()+" "+hours+":"+minutes+" "+ampm;
  return date1;
}
function setTotalReceiptRequestCounts(){
	var workStep = "CM";
	var type = "totalRequestedReceiptsCount";
	$.post("AppController/getDashBoardCounts",{workStep:workStep,type:type,loggedInUser:requestedBy},
		function(response)
		{
			$("#requestedRBs").val($.trim(response));
		}	
	);
}

function setProcessedReceiptsCount(){
	var workStep = "CM";
	var type = "processedReceiptsCount";
	$.post("AppController/getDashBoardCounts",{workStep:workStep,type:type,loggedInUser:requestedBy},
		function(response)
		{
			$("#processedRBs").val($.trim(response));
		}	
	);
}

function setReceiptSentToHOCount(){
	var workStep = "CM";
	var type = "receiptsSentToHO";
	$.post("AppController/getDashBoardCounts",{workStep:workStep,type:type,loggedInUser:requestedBy},
		function(response)
		{
			$("#returnedRBs").val($.trim(response));
		}	
	);

}
function setPendingReceiptRequest(){
	var workStep = "CM";
	var type = "pendingReceiptRequestCount";
	$.post("AppController/getDashBoardCounts",{workStep:workStep,type:type,loggedInUser:requestedBy},
		function(response)
		{
			$("#pendingRBs").val($.trim(response));
		}	
	);
}

function createAgencyList(){
	if($.trim($("#requestName").val())=="Agency"){
		$(".requestorNameCls").hide();
		$(".agencyListCls").show().focus();
		$("#requestLetter").removeAttr("disabled");
		setAgencyNamePredictions();
	}
	
}

function test(){
	var requestName = "";
	if($.trim($("#requestName").val())=="Agency")
		requestName = $.trim($("#agencyName").val());
	else
		requestName = $.trim($("#requestName").val())
	
	console.log("requestName: "+requestName);
}

function setAgencyNamePredictions(){

	$.ajaxSetup({async: false});
	$.post('AppController/getAgencyList',{},
			function(response)
			{
				var jsonArr = JSON.parse(response);
				var agencyListArr = [];
				for(var i=0;i<jsonArr.length;i++){
					agencyListArr.push(jsonArr[i].VENDOR_NAME);
				}

				// Constructing the suggestion engine
				var agencyList = new Bloodhound({
					datumTokenizer: Bloodhound.tokenizers.whitespace,
					queryTokenizer: Bloodhound.tokenizers.whitespace,
					local: agencyListArr
				});
				
				// Initializing the typeahead
				$('.agencyListCls').typeahead({
					hint: true,
					highlight: true,  //Enable substring highlighting 
					minLength: 1  //Specify minimum characters required for showing result 
				},
				{
					name: 'agencyList',
					source: agencyList
				});

			}
	);

}
