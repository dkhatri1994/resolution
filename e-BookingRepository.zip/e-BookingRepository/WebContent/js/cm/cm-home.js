$(document).ready(function(){
	$("#includeSideBarDiv").load("sidebars/cm-sidebar.jsp");// WEB-INF/views/cm/
	setProcessedRequestCountForDashboard();
	setConfirmedRequestCountForDashboard();
	setRaisedRequestCountForDashboard();
});

function setProcessedRequestCountForDashboard(){
	var workStep = "CM";
	var type = "processedRequestsCount";
	$.post("AppController/getDashBoardCounts",{workStep:workStep,type:type,loggedInUser:loggedInUser},
		function(response)
		{
			console.log("ProcessedRequestCount : "+response);
			setActivedTab("Dashboard");
		}	
	);
}

function setConfirmedRequestCountForDashboard(){
	var workStep = "CM";
	var type = "confirmedRequestCount";
	$.post("AppController/getDashBoardCounts",{workStep:workStep,type:type,loggedInUser:loggedInUser},
		function(response)
		{
			console.log("ConfirmedRequestCount : "+response);
		}	
	);
}

function setRaisedRequestCountForDashboard(){
	var workStep = "CM";
	var type = "myRaisedRequestCount";
	$.post("AppController/getDashBoardCounts",{workStep:workStep,type:type,loggedInUser:loggedInUser},
		function(response)
		{
			console.log("RaisedRequestCount : "+response);
			
		}	
	);
}