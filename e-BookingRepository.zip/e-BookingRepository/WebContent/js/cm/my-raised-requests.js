$(document).ready(function(){
	$("#includeSideBarDiv").load("sidebars/cm-sidebar.jsp");
	getRaisedRequests();
});

function getRaisedRequests(){
	var workStep = "CM";
	var type = "myRaisedRequests";
	$.ajaxSetup({async:false});
	$.post("AppController/getReceiptBookRequests",{workStep:workStep,type:type,loggedInUser:requestedBy},
		function(response)
		{
			var res = JSON.parse(response);
			var newHtml = "";
			for(var i=0;i<res.length;i++){
				newHtml += "<tr><td>"+(i+1)+"</td>"+
							"<td>"+res[i].TxID+"</td>"+
							"<td>"+res[i].RequestName+"</td>"+
							"<td>"+res[i].ReceiptQuantity+"</td>"+
							"<td>"+res[i].RequestTime+"</td>"+
							"<td>"+res[i].pendingDays+"</td>";
				newHtml += res[i].RequestStatus=="Processed"?"<td style='color:green;'>"+res[i].RequestStatus+"</td>":"<td style='color:red;'>"+res[i].RequestStatus+"</td>";
				newHtml += "</tr>";
			}
			$("#raisedRequestsTbody").html(newHtml);
		}	
	);
	$('#raisedRequestsTable').DataTable({
//		"bLengthChange" : false,
		"lengthMenu" : [10,15]
		/*dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ]*/
	});
//	$('#raisedRequestsTable_length').hide();
	$(".dataTables_filter").find('input').attr("placeholder","Universal Search");
	
	setActivedTab("Dashboard");
	
}

