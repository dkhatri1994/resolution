$(document).ready(function(){
	$("#includeSideBarDiv").load("sidebars/cm-sidebar.jsp");
	getAllReceiptBooks();
	
	$("#selectAllReceipts").click(function(){
		$(".checkBoxCls").prop("checked",$(this).prop("unchecked"));
	});
	
	$('input:checkbox').change(function() {
		var recBookNumber = $(this).closest("tr").find("td:nth-child(4)").text();
		var that = $(this);
		if($.trim(isLeafDetailsEntered(recBookNumber))=="false"){
			swal({
				  title: "Alert !",
				  text: "Leaf details has not been filled yet for this receipt book",
				  type: "warning",
				  confirmButtonText: "Cool"
				},function(){
					$(that).prop("checked", false);
				});
		}
	});
	$('.input-group.date').datepicker({
		format: "dd-mm-yyyy",
		startDate: '-0d',
		minViewMode: 0,
		clearBtn: true,
		todayHighlight: true,
		autoclose: true
	});
});

function getAllReceiptBooks(){
	var workstep = "CM";
	$.ajaxSetup({async:false});
	$.post("AppController/getAllReceiptBooks",{loggedInUser:loggedInUser,workstep:workstep},
		function(response)
		{
			var res = JSON.parse(response);
			var newHtml = "";
			for(var i=0;i<res.length;i++){
				newHtml += "<tr><td><input type='checkbox' class='checkBoxCls' id='selectReceiptBook_"+(i+1)+"'></td>"+
							"<td>"+(i+1)+"</td>"+
							"<td>"+res[i].TXID+"</td>"+
							"<td><a style='cursor:pointer;' data-toggle='modal' data-target='leafDetailsModal' onclick='showReceiptLeafs(this)'>"
								+res[i].RECEIPT_BOOK_NUMBER+"</a><a style='float:right;color: red;cursor: pointer;' onclick='showReceiptLeafLostModal(this)'>is Lost ?</a></td>"+
							"<td>"+res[i].SEQUENCE_START_NUMBER+"</td>"+
							"<td>"+res[i].SEQUENCE_END_NUMBER+"</td></tr>";
			}
			$("#receiptBookDetailsTbody").html(newHtml);
		}	
	);
	$('#receiptBookDetailsTable').DataTable({
		//"lengthMenu" : [10,15]
		'paging' : false
	});
//	$('#raisedRequestsTable_length').hide();
	$(".dataTables_filter").find('input').attr("placeholder","Universal Search");
	
	setActivedTab("Receipts send to HO");
	
}
function showReceiptLeafLostModal(thisObj){
	var startSeq = $(thisObj).parent().parent().find("td:eq(4)").text();
	var endSeq = $(thisObj).parent().parent().find("td:eq(5)").text();
	var txId = $(thisObj).parent().parent().find("td:eq(2)").text();
	var receiptBookNumber = $(thisObj).parent().find("a:first").text();
	var leafRange = startSeq+"-"+endSeq;
	$("#rHiddenTxId").val(txId);
	$("#rHiddenReceiptBookNumber").val(receiptBookNumber);
	$("#rHiddenLeafRange").val(leafRange);
	$("#lostReceiptBookReasonModal").modal('show');
}
function submitReceiptBookLostDetails(){
	var txId = $.trim($("#rHiddenTxId").val());
	var receiptBookNumber = $.trim($("#rHiddenReceiptBookNumber").val());
	var leafRange = $.trim($("#rHiddenLeafRange").val());
	var reasonOfLostReceiptBook = $.trim($("#reasonOfLostReceiptBook").val());
	var lostType = "ReceiptBook-Lost";
	$.post("AppController/submitLeafLostDetails",{lostType:lostType,leafNumber:leafRange,
		receiptBookNumber:receiptBookNumber,txId:txId,reasonOfLostleaf:reasonOfLostReceiptBook},
		function(response)
		{
			if($.trim(response)==1){
				swal({
					  title: "Alert !",
					  text: "Receipt Book lost details has been saved",
					  type: "success",
					  confirmButtonText: "Okay"
					},function(){
						$("#lostReceiptBookReasonModal").modal('hide');
					});
			}
			else{
				swal({
					  title: "Alert !",
					  text: "There is something wrong !",
					  type: "error",
					  confirmButtonText: "Okay"
					},function(){
						$("#lostReceiptBookReasonModal").modal('hide');
					});
			}
		}
	);

}

function showReceiptLeafs(thisObj){
	
	var startSeq = $(thisObj).parent().parent().find("td:eq(4)").text();
	var endSeq = $(thisObj).parent().parent().find("td:eq(5)").text();
	var txId = $(thisObj).parent().parent().find("td:eq(2)").text();
	var receiptBookNumber = $(thisObj).text();

	var isDetailsEntered = $.trim(isLeafDetailsEntered(receiptBookNumber));
//	console.log("txId : "+txId);
	var diff = endSeq - startSeq + 1;
	if(isDetailsEntered=="true"){
		swal({
			  title: "Alert !",
			  text: "Leaf details already has been entered for this receipt book",
			  type: "warning",
			  confirmButtonText: "Cool"
			});
	}
	else{
		$("#leafDetailsModal").modal('show');
		$("#leafInfoTbody").empty();
		$("#leafInfoTbody").html("");
//		$('#leafInfoTable').DataTable().destroy();
		var res = getLeafDetails(receiptBookNumber);
//		console.log("res : "+res.length);
		var newHtml = "";
		var isSequenceNoavai = true;
		for(var i=0;i<diff;i++){//i=startSeq;i<(endSeq+1);i++
			var mystartSeq = startSeq++;	
			isSequenceNoavai = true;
			for(var count=0;count<res.length;count++)
			{
			 var valSeq = res[count].SLIP_NUMBER;
			 if(mystartSeq==valSeq)
			 {
				 newHtml += "<tr id='rowid_"+(i+1)+"'><td>"+(i+1)+"</td><td>"+(mystartSeq)+"</td>";
				 if(res[count].LAN==null)
					 newHtml += "<td><input placeholder='Enter LAN Number' class='form-control' type='text' id='LAN_"+(i+1)+"'></td>";
				 else
					 newHtml += "<td><input value='"+res[count].LAN+"' class='form-control' type='text' id='LAN_"+(i+1)+"'></td>";
				 
				 
				 
				 if(res[count].CUSTOMER_NAME==null)
					 newHtml += "<td><input placeholder='Enter Customer Name' class='form-control' type='text' id='customerName_"+(i+1)+"'></td>";
				 else
					 newHtml += "<td><input value='"+res[count].CUSTOMER_NAME+"' class='form-control' type='text' id='customerName_"+(i+1)+"'></td>";
				 
				 if(res[count].PAYMENT_MODE==null){
					 newHtml += "<td><select class='form-control' id='paymentMode_"+(i+1)+"'>" +
						"<option value='Select'>Select</option>" +
						"<option value='Cash'>Cash</option>" +
						"<option value='DD'>DD</option>" +
						"<option value='NEFT'>NEFT</option>" +
						"<option value='RTGS'>RTGS</option>" +
						"<option value='Cheque'>Cheque</option></select></td>"; 
				 }
				 else
					 newHtml += "<td><input value='"+res[count].PAYMENT_MODE+"' class='form-control' type='text' id='paymentMode_"+(i+1)+"' ></td>";
				 
				 if(res[count].AMOUNT==null)
					 newHtml += "<td><input placeholder='Enter Amount' class='form-control' type='text' id='amount_"+(i+1)+"'></td>";
				 else
					 newHtml += "<td><input value='"+res[count].AMOUNT+"' class='form-control' type='text' id='amount_"+(i+1)+"'></td>";
				 
				 if(res[count].STATUS==null){
					 newHtml += "<td><select class='form-control' onchange='showLeafLostDetailsModal("+mystartSeq+","+receiptBookNumber+",\""+txId+"\",\"status_"+(i+1)+"\")' id='status_"+(i+1)+"'>" +
						"<option value='Select'>Select</option>" +
						"<option value='Issued'>Issued</option>" +
						"<option value='Cancelled'>Cancelled</option>" +
						"<option value='Lost'>Lost</option>" +
						"<option value='Empty'>Empty</option></select></td></tr>";
				 }
				 else
					 newHtml += "<td><input value='"+res[count].STATUS+"' class='form-control' type='text' id='status_"+(i+1)+"'></td></tr>";

				 isSequenceNoavai = false;
				 break;
			  }			 
			
		  }
			
//			console.log(mystartSeq +" is available : "+isSequenceNoavai);
			if(isSequenceNoavai)
			{
				newHtml += "<tr id='rowid_"+(i+1)+"'><td>"+(i+1)+"</td><td>"+(mystartSeq)+"</td>"+
				"<td><input placeholder='Enter LAN Number' class='form-control' type='text' id='LAN_"+(i+1)+"'></td>"+
				"<td><input placeholder='Enter Customer Name' class='form-control' type='text' id='customerName_"+(i+1)+"'></td>"+
				"<td><select class='form-control' id='paymentMode_"+(i+1)+"'>" +
						"<option value='Select'>Select</option>" +
						"<option value='Cash'>Cash</option>" +
						"<option value='DD'>DD</option>" +
						"<option value='NEFT'>NEFT</option>" +
						"<option value='RTGS'>RTGS</option>" +
						"<option value='Cheque'>Cheque</option></select></td>" +
				"<td><input placeholder='Enter Amount' class='form-control' type='text' id='amount_"+(i+1)+"'></td>"+
				"<td><select class='form-control' onchange='showLeafLostDetailsModal("+mystartSeq+","+receiptBookNumber+",\""+txId+"\",\"status_"+(i+1)+"\")' id='status_"+(i+1)+"'>" +
						"<option value='Select'>Select</option>" +
						"<option value='Issued'>Issued</option>" +
						"<option value='Cancelled'>Cancelled</option>" +
						"<option value='Lost'>Lost</option>" +
						"<option value='Empty'>Empty</option></select></td></tr>";
			}
		}
		newHtml += "<input type='hidden' id='receiptBookNumber' value='"+receiptBookNumber+"'>";
		$("#leafInfoTbody").html(newHtml);
	}	
}
function getLeafDetails(receiptBookNumber){
	var res = "";
	$.post("AppController/getLeafDetails",{receiptBookNumber:receiptBookNumber},
			function(response)
			{
				res = JSON.parse(response);
			}
		);
	return res;
}
function showLeafLostDetailsModal(mystartSeq,receiptBookNumber,txId,id){
//	console.log("id : "+id);
	if($.trim($("#"+id).val())=="Lost"){
		$("#lostLeafReasonModal").modal('show');
		$("#hiddenTxId").val(txId);
		$("#hiddenReceiptBookNumber").val(receiptBookNumber);
		$("#hiddenLeafNumber").val(mystartSeq);
	}
}
function submitLeafLostDetails(){
	var txId = $.trim($("#hiddenTxId").val());
	var receiptBookNumber = $.trim($("#hiddenReceiptBookNumber").val());
	var mystartSeq = $.trim($("#hiddenLeafNumber").val());
	var reasonOfLostleaf = $.trim($("#reasonOfLostleaf").val());
	var lostType = "Leaf-Lost";
	$.post("AppController/submitLeafLostDetails",{lostType:lostType,leafNumber:mystartSeq,
		receiptBookNumber:receiptBookNumber,txId:txId,reasonOfLostleaf:reasonOfLostleaf},
		function(response)
		{
			if($.trim(response)==1){
				swal({
					  title: "Alert !",
					  text: "Leaf lost details has been saved",
					  type: "success",
					  confirmButtonText: "Okay"
					},function(){
						$("#lostLeafReasonModal").modal('hide');
					});
			}
			else{
				swal({
					  title: "Alert !",
					  text: "There is something wrong !",
					  type: "error",
					  confirmButtonText: "Okay"
					},function(){
						$("#lostLeafReasonModal").modal('hide');
					});
			}
		}
	);
}
function saveLeafDetails(){
	var rowLength = $("#leafInfoTable >tbody >tr").length;
	var receiptBookNumber = $("#receiptBookNumber").val();
//	console.log($("#rowid_3 td:nth-child(2)").text());
	var leafData = "";
	var isValidated = validateLeafFields(rowLength);
	console.log("isValidated : "+isValidated);
	for(var i=0;i<rowLength;i++){
		leafData += $.trim($("#rowid_"+(i+1)+" td:nth-child(2)").text()) +"##"+ $.trim($("#LAN_"+(i+1)).val()) +"##"+ 
					$.trim($("#customerName_"+(i+1)).val()) +"##"+ $.trim($("#paymentMode_"+(i+1)).val()) +"##"+ 
					$.trim($("#amount_"+(i+1)).val())+"##"+ $.trim($("#status_"+(i+1)).val()) +"<END>";
	}
	if(isValidated){
		$.post("AppController/saveLeafData",{receiptBookNumber:receiptBookNumber,leafData:leafData},
				function(response)
				{
					swal({
						  title: "Alert !",
						  text: "Leaf details has been saved",
						  type: "success",
						  confirmButtonText: "Cool"
						},function(){
							$("#leafDetailsModal").modal('hide');
					});
				}
			);
	}
}

function validateLeafFields(rowLength){
//	console.log("rowlen : "+rowLength);
	for(var i=0;i<rowLength;i++){
		if($.trim($("#LAN_"+(i+1)).val())==""){
			swal({
				  title: "Alert !",
				  text: "Please enter Loan number in SNo : "+(i+1),
				  type: "error",
				  confirmButtonText: "Okay"
				});
			return false;
		}
		else if($.trim($("#customerName_"+(i+1)).val())==""){
			swal({
				  title: "Alert !",
				  text: "Please enter Customer name in SNo : "+(i+1),
				  type: "error",
				  confirmButtonText: "Okay"
				});
			return false;
		}
		else if($.trim($("#paymentMode_"+(i+1)).val())=="Select"){
			swal({
				  title: "Alert !",
				  text: "Please select payment mode in SNo : "+(i+1),
				  type: "error",
				  confirmButtonText: "Okay"
				});
			return false;
		}
		else if($.trim($("#amount_"+(i+1)).val())==""){
			swal({
				  title: "Alert !",
				  text: "Please enter amount in SNo : "+(i+1),
				  type: "error",
				  confirmButtonText: "Okay"
				});
			return false;
		}
		else if($.trim($("#status_"+(i+1)).val())=="Select"){
			swal({
				  title: "Alert !",
				  text: "Please select status in SNo :"+(i+1),
				  type: "error",
				  confirmButtonText: "Okay"
				});
			return false;
		}
	}
	return true;
}

function isLeafDetailsEntered(receiptBookNumber){
	var workStep = "CM";
	var queryType = "isLeafDetailsAvailable";
	var status = "";
	$.post("AppController/validationCounts",{workStep:workStep,queryType:queryType,receiptBookNumber:receiptBookNumber},
		function(response){
//			console.log("1 : "+response);
			status = response;
	});
	return status;
}

function sendReceiptsToHO(){
	var rows = $("#receiptBookDetailsTable tbody tr").length;
	var courierAgencyName = $.trim($("#courierAgencyName").val());
	var courierContactNumber = $.trim($("#courierContactNumber").val());
	var courierDispatchDate = $.trim($("#courierDispatchDate").val());
	var expectedDeliveryDate = $.trim($("#expectedDeliveryDate").val());
	var courierAddress = $.trim($("#courierAddress").val());
	console.log("courierAgencyName : "+$.trim($("#courierAgencyName").val()));
	var selectedReceiptBooks = [];
	var courierDetails = [];
	if(courierAgencyName=="" || courierContactNumber=="" || courierDispatchDate=="" || expectedDeliveryDate=="" || courierAddress==""){
		swal({
			  title: "Alert !",
			  text: "Please enter courier details",
			  type: "error",
			  confirmButtonText: "Cool"
			});
	}
	else{
		courierDetails.push(courierAgencyName);
		courierDetails.push(courierContactNumber);
		courierDetails.push(courierDispatchDate);
		courierDetails.push(expectedDeliveryDate);
		courierDetails.push(courierAddress);
		
		$('#receiptBookDetailsTable tbody tr input:checked').each(function() {
			selectedReceiptBooks.push($(this).closest('tr').find("td:nth-child(4)").text());
		});
		if(selectedReceiptBooks.length==0){
			swal({
				  title: "Alert !",
				  text: "Please select receipt book(s)",
				  type: "error",
				  confirmButtonText: "Cool"
				});
		}
		else{
			$.ajaxSetup({async:false});
			$.post("AppController/sentReceiptBooksToHO",{selectedReceiptBooks:selectedReceiptBooks.toString(),courierDetails:courierDetails.toString()},
					function(response)
					{
					swal({
						  title: "Alert !",
						  text: "Selected Receipt Books has been sent to HO",
						  type: "success",
						  confirmButtonText: "Cool"
						},function(){
							window.location.href = "send-to-ho";
					});
					}
				);

		}
	}
	
	
}
