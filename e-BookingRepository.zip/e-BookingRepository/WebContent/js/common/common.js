$(document).ready(function(){
	var welcomeName = "<i class='fa fa-user'></i> "+userFirstName+"<b class='caret'></b>";
	$("#welcomeName").html(welcomeName);
});

/*function setActiveTab(thisObj)
{
	var clickedValue = jQuery.trim(jQuery(thisObj).text());
	var tabValue = "";
	jQuery(".navbar-nav li").each(function()
	{
		tabValue = jQuery.trim(jQuery(this).find("a").text());
		if(tabValue==clickedValue)
		{
			jQuery(this).attr("class","active");
			alert(""+jQuery(this).find("a").text());
		}
		else
		{
			jQuery(this).attr("class","");
		}
		
	});
	console.log("setActiveTab calling..");
}*/
function setActivedTab(clickedVal)
{
	console.log("setActivedTab calling...");
	jQuery(".navbar-nav li").each(function()
	{
		tabValue = jQuery.trim(jQuery(this).find("a").text());
		if(tabValue==clickedVal)
		{
			jQuery(this).attr("class","active");
//			console.log(""+jQuery(this).find("a").text());
		}
		else
		{
			jQuery(this).attr("class","");
		}
		
	});
}