package com.assignment.file;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class FolderStats {

	long size;

	Map<String, Long> countByType = new HashMap<String, Long>();

	private static FolderStats folderstats = null;

	public static synchronized FolderStats getInstance() {
		if (folderstats == null) {
			folderstats = new FolderStats();
		}
		return folderstats;
	}

	/**
	 * @author Dev
	 * @param fileExtention
	 * @return this method will count files
	 */
	private void countFiles(String fileExtention) {
		try {
			if (fileExtention != "") {
				if (countByType.containsKey(fileExtention)) {
					long count = countByType.get(fileExtention);
					count++;
					countByType.put(fileExtention, count);
				} else {
					countByType.put(fileExtention, 1L);
				}
			}

		} catch (Exception e) {
			System.out.println("Error occured in countFiles method" + e);
		}

	}

	/**
	 * @author Dev
	 * @param folder
	 * @return size of folder in bytes
	 */
	private long getFolderSize(File folder) {
		long length = 0;
		File[] files = folder.listFiles();

		int count = files.length;

		for (int i = 0; i < count; i++) {
			if (files[i].isFile()) {
				length += files[i].length();
				countFiles(getFileExtension(files[i]));

			} else {
				length += getFolderSize(files[i]);
			}
		}
		return length;
	}

	/**
	 * @author Dev
	 * @param file
	 * @return This method will return file extention.
	 */
	private String getFileExtension(File file) {
		String name = file.getName();
		try {
			return name.substring(name.lastIndexOf(".") + 1);
		} catch (Exception e) {
			return "";
		}
	}

	@SuppressWarnings("unchecked")
	public JSONArray folderData(String dir) {
		JSONArray jsonarray = new JSONArray();
		try
		{
		File folder = new File(dir);
		long size = getFolderSize(folder);
		System.err.println("Sizee is " + size);
		JSONObject jsonobject = new JSONObject(countByType);
		JSONObject jsonobjectSize = new JSONObject();
		jsonobjectSize.put("folderSize", size);	
		jsonarray.add(jsonobject);
		jsonarray.add(jsonobjectSize);
		}
		catch(Exception e)
		{
			System.out.println("error in folderData" + e);
				
		}
		return jsonarray;
	}

}
