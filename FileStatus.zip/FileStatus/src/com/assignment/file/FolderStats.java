package com.assignment.file;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class FolderStats {

	private static FolderStats folderstats= null;
	
	public static synchronized FolderStats getInstance()
	{
		if(folderstats == null)
		{
			folderstats = new FolderStats();
		}
		return folderstats;
	}
	
	@SuppressWarnings("unchecked")
	public JSONArray folderSize()
	{
		JSONArray jsonarray = new JSONArray();
		JSONObject jsonobject = new JSONObject();
		jsonobject.put("file", 5);
		jsonarray.add(jsonobject);
		return jsonarray;
	}
	
}
